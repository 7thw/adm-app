// convex/schema.ts - Realigna Complete Production Schema
// Based on PRD requirements + Convex/Clerk best practices + Performance optimization

import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  // =================================================================
  // CORE USER MANAGEMENT (Clerk Integration)
  // =================================================================

  users: defineTable({
    clerkId: v.string(),
    tokenIdentifier: v.string(),
    role: v.union(v.literal("admin"), v.literal("subscriber")),
    email: v.string(),
    name: v.optional(v.string()),
    avatarUrl: v.optional(v.string()),
    lastActiveAt: v.number(),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_clerk_id", ["clerkId"])
    .index("by_token_identifier", ["tokenIdentifier"])
    .index("by_role", ["role"])
    .index("by_role_created", ["role", "createdAt"])
    .index("by_last_active", ["lastActiveAt"]),

  // =================================================================
  // ADMIN CONTENT MANAGEMENT
  // =================================================================

  // Playlist Categories for Core content organization
  coreCategories: defineTable({
    name: v.string(),
    description: v.optional(v.string()),
    slug: v.string(),
    isActive: v.boolean(),
    order: v.number(),
    color: v.optional(v.string()), // UI theming
    iconUrl: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_active", ["isActive"])
    .index("by_order", ["order"])
    .index("by_slug", ["slug"])
    .index("by_active_order", ["isActive", "order"]),

  // Media files (audio uploads + video embeds)
  medias: defineTable({
    title: v.string(),
    description: v.optional(v.string()),
    mediaType: v.union(v.literal("audio"), v.literal("video")),
    mediaUrl: v.string(),
    thumbnailUrl: v.optional(v.string()),
    duration: v.number(), // in seconds
    fileSize: v.optional(v.number()), // in bytes
    uploadKey: v.optional(v.string()), // R2 upload key
    contentType: v.optional(v.string()), // MIME type
    uploadStatus: v.optional(v.union(
      v.literal("pending"),
      v.literal("processing"),
      v.literal("completed"),
      v.literal("failed")
    )),
    // Enhanced metadata for rich features
    tags: v.optional(v.array(v.string())),
    transcript: v.optional(v.string()), // For audio content
    waveformData: v.optional(v.string()), // For audio visualization
    youtubeId: v.optional(v.string()), // For video embeds
    quality: v.optional(v.string()), // HD, SD, etc.
    bitrate: v.optional(v.number()),
    uploadedBy: v.string(), // Clerk user ID
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_type", ["mediaType"])
    .index("by_status", ["uploadStatus"])
    .index("by_uploader", ["uploadedBy"])
    .index("by_tags", ["tags"])
    .index("by_type_status", ["mediaType", "uploadStatus"])
    .index("by_created", ["createdAt"]),

  // Core Playlists (Admin-managed content)
  corePlaylists: defineTable({
    title: v.string(),
    description: v.optional(v.string()),
    thumbnailUrl: v.optional(v.string()),
    status: v.union(v.literal("draft"), v.literal("published")),
    categoryId: v.id("coreCategories"),
    playCount: v.number(),
    averageRating: v.optional(v.number()),
    totalDuration: v.optional(v.number()), // calculated field
    difficulty: v.optional(v.union(
      v.literal("beginner"),
      v.literal("intermediate"),
      v.literal("advanced")
    )),
    tags: v.optional(v.array(v.string())),
    createdBy: v.string(), // Clerk user ID
    publishedAt: v.optional(v.number()),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_status", ["status"])
    .index("by_category", ["categoryId"])
    .index("by_published", ["status", "createdAt"])
    .index("by_category_status", ["categoryId", "status"])
    .index("by_status_updated", ["status", "updatedAt"])
    .index("by_play_count", ["playCount"])
    .index("by_creator", ["createdBy"]),

  // Core Sections within playlists
  coreSections: defineTable({
    playlistId: v.id("corePlaylists"),
    title: v.string(),
    description: v.optional(v.string()),
    sectionType: v.union(v.literal("base"), v.literal("loop")),
    minSelectMedia: v.number(),
    maxSelectMedia: v.number(),
    order: v.number(),
    isRequired: v.boolean(), // Whether this section must be completed
    estimatedDuration: v.optional(v.number()),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_playlist", ["playlistId"])
    .index("by_playlist_order", ["playlistId", "order"])
    .index("by_type", ["sectionType"]),

  // Media linked to sections
  sectionMedias: defineTable({
    sectionId: v.id("coreSections"),
    mediaId: v.id("medias"),
    order: v.number(),
    isOptional: v.boolean(), // Whether this media is optional in the section
    createdAt: v.number(),
  })
    .index("by_section", ["sectionId"])
    .index("by_section_order", ["sectionId", "order"])
    .index("by_media", ["mediaId"]),

  // =================================================================
  // SUBSCRIBER CUSTOMIZATION & EXPERIENCE
  // =================================================================

  // Subscriber's customized playlists
  subscriberPlaylists: defineTable({
    userId: v.string(), // Clerk user ID
    corePlaylistId: v.id("corePlaylists"),
    title: v.string(), // User can customize the title
    customPlaylists: v.string(), // JSON string of customized playlist data
    isActive: v.boolean(),
    isFavorite: v.boolean(),
    playCount: v.number(),
    lastPlayed: v.optional(v.number()),
    completionPercentage: v.optional(v.number()),
    totalTimeSpent: v.optional(v.number()), // in seconds
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_user_active", ["userId", "isActive"])
    .index("by_user_updated", ["userId", "updatedAt"])
    .index("by_user_favorites", ["userId", "isFavorite"])
    .index("by_core_playlist", ["corePlaylistId"])
    .index("by_last_played", ["lastPlayed"]),

  // Subscriber's media selections per section
  subscriberMediaSelections: defineTable({
    subscriberPlaylistId: v.id("subscriberPlaylists"),
    sectionId: v.id("coreSections"),
    mediaId: v.id("medias"),
    isSelected: v.boolean(),
    playOrder: v.number(),
    completedAt: v.optional(v.number()),
    timeSpent: v.optional(v.number()), // in seconds
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_subscriber_playlist", ["subscriberPlaylistId"])
    .index("by_section", ["sectionId"])
    .index("by_media", ["mediaId"])
    .index("by_selected", ["isSelected"]),

  // User player settings and preferences
  userPlayerSettings: defineTable({
    userId: v.string(), // Clerk user ID
    playerSettings: v.object({
      maxLoop: v.number(), // 0, 1, 2, 3, or -1 for infinite
      countDownTimer: v.number(), // minutes
      volume: v.number(), // 0-100
      autoPlay: v.boolean(),
      shuffleMode: v.boolean(),
      backgroundPlayback: v.boolean(),
    }),
    currentPlaylistId: v.optional(v.id("subscriberPlaylists")),
    currentMediaId: v.optional(v.id("medias")),
    currentTime: v.number(), // current playback time in seconds
    playbackSpeed: v.number(), // 0.5x to 2.0x
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_user", ["userId"]),

  // PWA offline settings and cached data reference
  subscriberSettings: defineTable({
    userId: v.string(), // Clerk user ID
    customPlaylists: v.string(), // JSON string of offline cached playlists
    preferences: v.object({
      autoSync: v.boolean(),
      offlineMode: v.boolean(),
      downloadQuality: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
      wifiOnlyDownload: v.boolean(),
    }),
    deviceInfo: v.optional(v.object({
      deviceType: v.string(),
      browserType: v.string(),
      storageUsed: v.number(),
      storageLimit: v.number(),
    })),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_user", ["userId"]),

  // =================================================================
  // FILE STORAGE & R2 INTEGRATION
  // =================================================================

  r2Files: defineTable({
    uploadKey: v.string(),
    fileName: v.string(),
    originalName: v.string(),
    fileSize: v.number(),
    contentType: v.string(),
    uploadStatus: v.union(
      v.literal("pending"),
      v.literal("processing"),
      v.literal("completed"),
      v.literal("failed")
    ),
    mediaId: v.optional(v.id("medias")), // Link to media after processing
    uploadedBy: v.string(), // Clerk user ID
    uploadProgress: v.optional(v.number()), // 0-100
    errorMessage: v.optional(v.string()),
    processingMetadata: v.optional(v.string()), // JSON string
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_upload_key", ["uploadKey"])
    .index("by_status", ["uploadStatus"])
    .index("by_user", ["uploadedBy"])
    .index("by_media", ["mediaId"]),

  // =================================================================
  // ANALYTICS & TRACKING
  // =================================================================

  // Analytics events for user behavior tracking
  analyticsEvents: defineTable({
    userId: v.string(), // Clerk user ID
    eventType: v.string(), // "playlist_start", "media_complete", "section_skip", etc.
    eventData: v.optional(v.string()), // JSON string with event details
    playlistId: v.optional(v.id("subscriberPlaylists")),
    mediaId: v.optional(v.id("medias")),
    sessionId: v.optional(v.string()),
    deviceType: v.optional(v.string()),
    timestamp: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_type", ["eventType"])
    .index("by_date", ["timestamp"])
    .index("by_user_date", ["userId", "timestamp"])
    .index("by_session", ["sessionId"]),

  // Admin action audit trail
  adminActions: defineTable({
    adminUserId: v.string(), // Clerk user ID
    action: v.string(), // "create_playlist", "publish_playlist", "delete_media", etc.
    targetType: v.string(), // "playlist", "media", "user", "category"
    targetId: v.string(),
    details: v.optional(v.string()), // JSON string with action details
    ipAddress: v.optional(v.string()),
    userAgent: v.optional(v.string()),
    createdAt: v.number(),
  })
    .index("by_admin", ["adminUserId"])
    .index("by_target", ["targetType", "targetId"])
    .index("by_date", ["createdAt"])
    .index("by_action", ["action"]),

  // =================================================================
  // PERFORMANCE & MONITORING
  // =================================================================

  // Performance monitoring for function execution
  performanceMetrics: defineTable({
    functionName: v.string(),
    executionTime: v.number(), // in milliseconds
    userId: v.optional(v.string()),
    timestamp: v.number(),
    success: v.boolean(),
    errorMessage: v.optional(v.string()),
    memoryUsage: v.optional(v.number()),
    queryCount: v.optional(v.number()),
  })
    .index("by_function", ["functionName"])
    .index("by_performance", ["functionName", "executionTime"])
    .index("by_errors", ["success", "timestamp"])
    .index("by_date", ["timestamp"]),

  // =================================================================
  // NOTIFICATIONS & MESSAGING
  // =================================================================

  // System notifications for users
  notifications: defineTable({
    userId: v.string(), // Clerk user ID
    type: v.union(
      v.literal("system"),
      v.literal("playlist_update"),
      v.literal("subscription"),
      v.literal("achievement")
    ),
    title: v.string(),
    message: v.string(),
    isRead: v.boolean(),
    actionUrl: v.optional(v.string()),
    metadata: v.optional(v.string()), // JSON string
    expiresAt: v.optional(v.number()),
    createdAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_user_unread", ["userId", "isRead"])
    .index("by_type", ["type"])
    .index("by_expiry", ["expiresAt"]),

  // =================================================================
  // USER PROFILES & ROLE MANAGEMENT
  // =================================================================

  // Extended data for admin users
  adminProfiles: defineTable({
    userId: v.id("users"),
    clerkId: v.string(),
    permissions: v.array(v.string()),
    adminRole: v.union(
      v.literal("admin"),
      v.literal("manager"),
    ),
    organizationId: v.optional(v.string()),
    organizationRole: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_user_id", ["userId"])
    .index("by_clerk_id", ["clerkId"])
    .index("by_admin_role", ["adminRole"])
    .index("by_organization_id", ["organizationId"]),

  // Extended data for subscriber users
  subscriberProfiles: defineTable({
    userId: v.id("users"),
    clerkId: v.string(),
    subscriptionStatus: v.union(
      v.literal("active"),
      v.literal("trialing"),
      v.literal("past_due"),
      v.literal("canceled"),
      v.literal("incomplete"),
      v.literal("incomplete_expired")
    ),
    subscriptionPlan: v.string(),
    subscriptionId: v.string(),
    entitlements: v.array(v.string()),
    priceId: v.optional(v.string()),
    currentPeriodEnd: v.optional(v.number()),
    cancelAtPeriodEnd: v.optional(v.boolean()),
    trialEnd: v.optional(v.number()),
    customerId: v.optional(v.string()),
    metadata: v.optional(v.string()), // JSON string with additional data
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_user_id", ["userId"])
    .index("by_clerk_id", ["clerkId"])
    .index("by_subscription_status", ["subscriptionStatus"])
    .index("by_subscription_plan", ["subscriptionPlan"]),

  // =================================================================
  // SUBSCRIPTION & BILLING INTEGRATION
  // =================================================================

  // Subscription usage tracking (complementary to Clerk Billing)
  subscriptionUsage: defineTable({
    userId: v.string(), // Clerk user ID
    period: v.string(), // "2024-01", month-year format
    playlistsCreated: v.number(),
    mediaPlayed: v.number(),
    totalPlayTime: v.number(), // in seconds
    downloadsUsed: v.number(),
    featuresUsed: v.array(v.string()),
    lastUpdated: v.number(),
    createdAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_period", ["period"])
    .index("by_user_period", ["userId", "period"]),
});
