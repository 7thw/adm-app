import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { requireAuth } from "./auth";

/**
 * Create or update a subscriber playlist
 */
export const createSubscriberPlaylist = mutation({
  args: {
    corePlaylistId: v.id("corePlaylists"),
    title: v.optional(v.string()),
    customPlaylists: v.optional(v.string()),
    isFavorite: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const user = await requireAuth(ctx);
    
    const now = Date.now();
    
    // Check if the core playlist exists
    const corePlaylist = await ctx.db.get(args.corePlaylistId);
    if (!corePlaylist) {
      throw new Error("Playlist not found");
    }
    
    // Check if the user already has a subscriber playlist for this core playlist
    const existingPlaylist = await ctx.db
      .query("subscriberPlaylists")
      .withIndex("by_user", (q) => q.eq("userId", user.clerkId))
      .filter((q) => q.eq(q.field("corePlaylistId"), args.corePlaylistId))
      .first();
    
    if (existingPlaylist) {
      // Update existing playlist
      return await ctx.db.patch(existingPlaylist._id, {
        title: args.title ?? existingPlaylist.title,
        customPlaylists: args.customPlaylists ?? existingPlaylist.customPlaylists,
        isFavorite: args.isFavorite ?? existingPlaylist.isFavorite,
        updatedAt: now,
      });
    } else {
      // Create new subscriber playlist
      return await ctx.db.insert("subscriberPlaylists", {
        userId: user.clerkId,
        corePlaylistId: args.corePlaylistId,
        title: args.title ?? corePlaylist.title,
        customPlaylists: args.customPlaylists ?? "{}",
        isActive: true,
        isFavorite: args.isFavorite ?? false,
        playCount: 0,
        completionPercentage: 0,
        totalTimeSpent: 0,
        createdAt: now,
        updatedAt: now,
      });
    }
  },
});

/**
 * Update a subscriber playlist
 */
export const updateSubscriberPlaylist = mutation({
  args: {
    subscriberPlaylistId: v.id("subscriberPlaylists"),
    title: v.optional(v.string()),
    customPlaylists: v.optional(v.string()),
    isActive: v.optional(v.boolean()),
    isFavorite: v.optional(v.boolean()),
    completionPercentage: v.optional(v.number()),
    totalTimeSpent: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const user = await requireAuth(ctx);
    
    const { subscriberPlaylistId, ...updates } = args;
    
    // Get the subscriber playlist
    const playlist = await ctx.db.get(subscriberPlaylistId);
    if (!playlist) {
      throw new Error("Subscriber playlist not found");
    }
    
    // Verify ownership
    if (playlist.userId !== user.clerkId) {
      throw new Error("You don't have permission to update this playlist");
    }
    
    return await ctx.db.patch(subscriberPlaylistId, {
      ...updates,
      updatedAt: Date.now(),
    });
  },
});

/**
 * Delete a subscriber playlist
 */
export const deleteSubscriberPlaylist = mutation({
  args: {
    subscriberPlaylistId: v.id("subscriberPlaylists"),
  },
  handler: async (ctx, args) => {
    const user = await requireAuth(ctx);
    
    // Get the subscriber playlist
    const playlist = await ctx.db.get(args.subscriberPlaylistId);
    if (!playlist) {
      throw new Error("Subscriber playlist not found");
    }
    
    // Verify ownership
    if (playlist.userId !== user.clerkId) {
      throw new Error("You don't have permission to delete this playlist");
    }
    
    // Delete all media selections first
    const selections = await ctx.db
      .query("subscriberMediaSelections")
      .withIndex("by_subscriber_playlist", (q) => 
        q.eq("subscriberPlaylistId", args.subscriberPlaylistId)
      )
      .collect();
      
    for (const selection of selections) {
      await ctx.db.delete(selection._id);
    }
    
    // Delete the playlist
    await ctx.db.delete(args.subscriberPlaylistId);
    
    return { success: true };
  },
});

/**
 * List subscriber playlists for the current user
 */
export const listMyPlaylists = query({
  args: {
    activeOnly: v.optional(v.boolean()),
    favoritesOnly: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const user = await requireAuth(ctx);
    
    let query = ctx.db.query("subscriberPlaylists")
      .withIndex("by_user", (q) => q.eq("userId", user.clerkId));
    
    if (args.activeOnly) {
      query = ctx.db.query("subscriberPlaylists")
        .withIndex("by_user_active", (q) => 
          q.eq("userId", user.clerkId).eq("isActive", true)
        );
    }
    
    if (args.favoritesOnly) {
      query = ctx.db.query("subscriberPlaylists")
        .withIndex("by_user_favorites", (q) => 
          q.eq("userId", user.clerkId).eq("isFavorite", true)
        );
    }
    
    const subscriberPlaylists = await query.order("desc").collect();
    
    // Get the core playlists for additional info
    const corePlaylistIds = [...new Set(subscriberPlaylists.map(p => p.corePlaylistId))];
    const corePlaylists = await Promise.all(
      corePlaylistIds.map(id => ctx.db.get(id))
    );
    
    // Build a map for easier lookup
    const corePlaylistMap = Object.fromEntries(
      corePlaylists.filter(Boolean).map(p => [p!._id, p])
    );
    
    // Enhance subscriber playlists with core playlist info
    return subscriberPlaylists.map(p => ({
      ...p,
      corePlaylist: corePlaylistMap[p.corePlaylistId],
    }));
  },
});

/**
 * Get a specific subscriber playlist with media selections
 */
export const getSubscriberPlaylist = query({
  args: {
    subscriberPlaylistId: v.id("subscriberPlaylists"),
  },
  handler: async (ctx, args) => {
    const user = await requireAuth(ctx);
    
    // Get the subscriber playlist
    const playlist = await ctx.db.get(args.subscriberPlaylistId);
    if (!playlist) {
      return null;
    }
    
    // Verify ownership
    if (playlist.userId !== user.clerkId) {
      throw new Error("You don't have permission to view this playlist");
    }
    
    // Get the core playlist
    const corePlaylist = await ctx.db.get(playlist.corePlaylistId);
    
    // Get all sections in the core playlist
    const sections = await ctx.db
      .query("coreSections")
      .withIndex("by_playlist_order", (q) => 
        q.eq("playlistId", playlist.corePlaylistId)
      )
      .collect();
    
    // Get media selections for this subscriber playlist
    const selections = await ctx.db
      .query("subscriberMediaSelections")
      .withIndex("by_subscriber_playlist", (q) => 
        q.eq("subscriberPlaylistId", args.subscriberPlaylistId)
      )
      .collect();
    
    // Group selections by section
    const selectionsBySection = {};
    for (const selection of selections) {
      const sectionId = selection.sectionId;
      if (!selectionsBySection[sectionId]) {
        selectionsBySection[sectionId] = [];
      }
      selectionsBySection[sectionId].push(selection);
    }
    
    // Enhance sections with their media selections
    const enhancedSections = await Promise.all(
      sections.map(async (section) => {
        const sectionSelections = selectionsBySection[section._id] || [];
        
        // Get media details for selections
        const mediaSelections = await Promise.all(
          sectionSelections.map(async (selection) => {
            const media = await ctx.db.get(selection.mediaId);
            return { ...selection, media };
          })
        );
        
        return {
          ...section,
          mediaSelections: mediaSelections.filter(s => s.media),
        };
      })
    );
    
    return {
      ...playlist,
      corePlaylist,
      sections: enhancedSections,
    };
  },
});

/**
 * Select or deselect media in a subscriber playlist
 */
export const toggleMediaSelection = mutation({
  args: {
    subscriberPlaylistId: v.id("subscriberPlaylists"),
    sectionId: v.id("coreSections"),
    mediaId: v.id("medias"),
    isSelected: v.boolean(),
    playOrder: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const user = await requireAuth(ctx);
    
    // Verify playlist ownership
    const playlist = await ctx.db.get(args.subscriberPlaylistId);
    if (!playlist || playlist.userId !== user.clerkId) {
      throw new Error("You don't have permission to modify this playlist");
    }
    
    const now = Date.now();
    
    // Check if a selection already exists
    const existingSelection = await ctx.db
      .query("subscriberMediaSelections")
      .withIndex("by_subscriber_playlist", (q) => 
        q.eq("subscriberPlaylistId", args.subscriberPlaylistId)
      )
      .filter((q) => 
        q.eq(q.field("sectionId"), args.sectionId) &&
        q.eq(q.field("mediaId"), args.mediaId)
      )
      .first();
    
    if (existingSelection) {
      // Update existing selection
      return await ctx.db.patch(existingSelection._id, {
        isSelected: args.isSelected,
        playOrder: args.playOrder ?? existingSelection.playOrder,
        updatedAt: now,
      });
    } else {
      // Create new selection
      return await ctx.db.insert("subscriberMediaSelections", {
        subscriberPlaylistId: args.subscriberPlaylistId,
        sectionId: args.sectionId,
        mediaId: args.mediaId,
        isSelected: args.isSelected,
        playOrder: args.playOrder ?? 0,
        createdAt: now,
        updatedAt: now,
      });
    }
  },
});

/**
 * Record play history
 */
export const recordPlay = mutation({
  args: {
    mediaId: v.id("medias"),
    subscriberPlaylistId: v.optional(v.id("subscriberPlaylists")),
    duration: v.number(),
    completionRate: v.number(),
  },
  handler: async (ctx, args) => {
    const user = await requireAuth(ctx);
    
    const now = Date.now();
    
    // Record analytics event
    await ctx.db.insert("analyticsEvents", {
      userId: user.clerkId,
      eventType: "media_play",
      eventData: JSON.stringify({
        mediaId: args.mediaId,
        subscriberPlaylistId: args.subscriberPlaylistId,
        duration: args.duration,
        completionRate: args.completionRate,
      }),
      mediaId: args.mediaId,
      playlistId: args.subscriberPlaylistId,
      timestamp: now,
    });
    
    // Increment playlist play count if applicable
    if (args.subscriberPlaylistId) {
      const playlist = await ctx.db.get(args.subscriberPlaylistId);
      if (playlist) {
        await ctx.db.patch(args.subscriberPlaylistId, {
          playCount: (playlist.playCount || 0) + 1,
          lastPlayed: now,
          updatedAt: now,
        });
      }
    }
    
    return {
      success: true,
      timestamp: now,
    };
  },
});
