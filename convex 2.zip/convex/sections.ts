import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { requireAdmin, requireAuth } from "./auth";

/**
 * Create a new section in a playlist (admin only)
 */
export const createSection = mutation({
  args: {
    playlistId: v.id("corePlaylists"),
    title: v.string(),
    description: v.optional(v.string()),
    sectionType: v.union(v.literal("base"), v.literal("loop")),
    minSelectMedia: v.number(),
    maxSelectMedia: v.number(),
    order: v.number(),
    isRequired: v.boolean(),
    estimatedDuration: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    // Verify playlist exists
    const playlist = await ctx.db.get(args.playlistId);
    if (!playlist) {
      throw new Error("Playlist not found");
    }
    
    const now = Date.now();
    
    return await ctx.db.insert("coreSections", {
      ...args,
      createdAt: now,
      updatedAt: now,
    });
  },
});

/**
 * Update an existing section (admin only)
 */
export const updateSection = mutation({
  args: {
    sectionId: v.id("coreSections"),
    title: v.optional(v.string()),
    description: v.optional(v.string()),
    sectionType: v.optional(v.union(v.literal("base"), v.literal("loop"))),
    minSelectMedia: v.optional(v.number()),
    maxSelectMedia: v.optional(v.number()),
    order: v.optional(v.number()),
    isRequired: v.optional(v.boolean()),
    estimatedDuration: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    const { sectionId, ...updates } = args;
    
    // Verify section exists
    const section = await ctx.db.get(sectionId);
    if (!section) {
      throw new Error("Section not found");
    }
    
    return await ctx.db.patch(sectionId, {
      ...updates,
      updatedAt: Date.now(),
    });
  },
});

/**
 * Delete a section and its media associations (admin only)
 */
export const deleteSection = mutation({
  args: {
    sectionId: v.id("coreSections"),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    // Delete all media associations first
    const sectionMedias = await ctx.db
      .query("sectionMedias")
      .withIndex("by_section", (q) => q.eq("sectionId", args.sectionId))
      .collect();
      
    for (const sectionMedia of sectionMedias) {
      await ctx.db.delete(sectionMedia._id);
    }
    
    // Delete subscriber media selections for this section
    const subscriberSelections = await ctx.db
      .query("subscriberMediaSelections")
      .withIndex("by_section", (q) => q.eq("sectionId", args.sectionId))
      .collect();
      
    for (const selection of subscriberSelections) {
      await ctx.db.delete(selection._id);
    }
    
    // Delete the section
    await ctx.db.delete(args.sectionId);
    
    return { success: true };
  },
});

/**
 * List sections for a playlist
 */
export const listSections = query({
  args: {
    playlistId: v.id("corePlaylists"),
  },
  handler: async (ctx, args) => {
    await requireAuth(ctx);
    
    return await ctx.db
      .query("coreSections")
      .withIndex("by_playlist_order", (q) => 
        q.eq("playlistId", args.playlistId)
      )
      .collect();
  },
});

/**
 * Get a section by ID with its media items
 */
export const getSectionWithMedia = query({
  args: {
    sectionId: v.id("coreSections"),
  },
  handler: async (ctx, args) => {
    await requireAuth(ctx);
    
    const section = await ctx.db.get(args.sectionId);
    if (!section) {
      return null;
    }
    
    // Get all media in this section
    const sectionMedias = await ctx.db
      .query("sectionMedias")
      .withIndex("by_section_order", (q) => 
        q.eq("sectionId", args.sectionId)
      )
      .collect();
    
    // Get actual media content
    const mediaItems = await Promise.all(
      sectionMedias.map(async (sm) => {
        const media = await ctx.db.get(sm.mediaId);
        return {
          ...sm,
          media,
        };
      })
    );
    
    // Filter out any items where media was deleted
    const validMediaItems = mediaItems.filter(item => item.media !== null);
    
    return {
      ...section,
      mediaItems: validMediaItems,
    };
  },
});

/**
 * Add media to a section (admin only)
 */
export const addMediaToSection = mutation({
  args: {
    sectionId: v.id("coreSections"),
    mediaId: v.id("medias"),
    order: v.number(),
    isOptional: v.boolean(),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    // Check if the media already exists in this section
    const existingMedia = await ctx.db
      .query("sectionMedias")
      .withIndex("by_section", (q) => q.eq("sectionId", args.sectionId))
      .filter((q) => q.eq(q.field("mediaId"), args.mediaId))
      .first();
      
    if (existingMedia) {
      throw new Error("This media is already in the section");
    }
    
    // Add the media to the section
    return await ctx.db.insert("sectionMedias", {
      sectionId: args.sectionId,
      mediaId: args.mediaId,
      order: args.order,
      isOptional: args.isOptional,
      createdAt: Date.now(),
    });
  },
});

/**
 * Update media order or optional status in a section (admin only)
 */
export const updateSectionMedia = mutation({
  args: {
    sectionMediaId: v.id("sectionMedias"),
    order: v.optional(v.number()),
    isOptional: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    const { sectionMediaId, ...updates } = args;
    
    // Check if the section media exists
    const sectionMedia = await ctx.db.get(sectionMediaId);
    if (!sectionMedia) {
      throw new Error("Section media not found");
    }
    
    return await ctx.db.patch(sectionMediaId, updates);
  },
});

/**
 * Remove media from a section (admin only)
 */
export const removeMediaFromSection = mutation({
  args: {
    sectionMediaId: v.id("sectionMedias"),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    // Get the section media to check for subscriber selections
    const sectionMedia = await ctx.db.get(args.sectionMediaId);
    if (!sectionMedia) {
      throw new Error("Section media not found");
    }
    
    // Delete any subscriber selections for this media in this section
    const subscriberSelections = await ctx.db
      .query("subscriberMediaSelections")
      .withIndex("by_media", (q) => q.eq("mediaId", sectionMedia.mediaId))
      .filter((q) => q.eq(q.field("sectionId"), sectionMedia.sectionId))
      .collect();
      
    for (const selection of subscriberSelections) {
      await ctx.db.delete(selection._id);
    }
    
    // Delete the section media
    await ctx.db.delete(args.sectionMediaId);
    
    return { success: true };
  },
});

/**
 * Reorder all media in a section (admin only)
 */
export const reorderSectionMedia = mutation({
  args: {
    sectionId: v.id("coreSections"),
    mediaOrders: v.array(
      v.object({
        sectionMediaId: v.id("sectionMedias"),
        order: v.number(),
      })
    ),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    // Update each section media with its new order
    for (const { sectionMediaId, order } of args.mediaOrders) {
      await ctx.db.patch(sectionMediaId, { order });
    }
    
    return { success: true };
  },
});
