import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { requireAdmin, requireAuth } from "./auth";

/**
 * Webhook handler for Clerk Billing subscription events
 * This should be called from a webhook endpoint to sync subscription data
 */
export const handleSubscriptionWebhook = mutation({
  args: {
    clerkId: v.string(),
    subscriptionId: v.string(),
    priceId: v.string(),
    status: v.string(),
    currentPeriodEnd: v.number(),
    cancelAtPeriodEnd: v.boolean(),
    metadata: v.optional(v.string()), // JSON string with additional subscription metadata
    features: v.optional(v.array(v.string())),
    plan: v.string(),
  },
  handler: async (ctx, args) => {
    // Note: This doesn't require auth since it's called from a webhook
    // In production, you would verify the webhook signature
    
    const now = Date.now();
    
    // Find the user by clerkId
    const user = await ctx.db
      .query("users")
      .withIndex("by_clerk_id", (q) => q.eq("clerkId", args.clerkId))
      .first();
    
    if (!user) {
      throw new Error(`User with Clerk ID ${args.clerkId} not found`);
    }
    
    // Update the user's plan and features
    await ctx.db.patch(user._id, {
      plan: args.plan,
      features: args.features || [],
      updatedAt: now,
    });
    
    // Check if subscriptionUsage record exists
    const existingUsage = await ctx.db
      .query("subscriptionUsage")
      .withIndex("by_clerk_user", (q) => q.eq("clerkId", args.clerkId))
      .first();
    
    if (existingUsage) {
      // Update existing record
      await ctx.db.patch(existingUsage._id, {
        subscriptionId: args.subscriptionId,
        priceId: args.priceId,
        status: args.status,
        currentPeriodEnd: args.currentPeriodEnd,
        cancelAtPeriodEnd: args.cancelAtPeriodEnd,
        metadata: args.metadata || existingUsage.metadata,
        features: args.features || existingUsage.features,
        plan: args.plan,
        updatedAt: now,
      });
    } else {
      // Create new subscription record
      await ctx.db.insert("subscriptionUsage", {
        clerkId: args.clerkId,
        userId: user._id,
        subscriptionId: args.subscriptionId,
        priceId: args.priceId,
        status: args.status,
        currentPeriodEnd: args.currentPeriodEnd,
        cancelAtPeriodEnd: args.cancelAtPeriodEnd,
        metadata: args.metadata || "{}",
        features: args.features || [],
        plan: args.plan,
        usage: {},
        createdAt: now,
        updatedAt: now,
      });
    }
    
    // Log the subscription change
    await ctx.db.insert("analyticsEvents", {
      userId: args.clerkId,
      eventType: "subscription_update",
      eventData: JSON.stringify({
        subscriptionId: args.subscriptionId,
        plan: args.plan,
        status: args.status,
        features: args.features || [],
      }),
      timestamp: now,
    });
    
    return { success: true };
  },
});

/**
 * Track usage of a subscription feature
 */
export const trackUsage = mutation({
  args: {
    feature: v.string(),
    quantity: v.number(),
  },
  handler: async (ctx, args) => {
    const user = await requireAuth(ctx);
    
    // Find the subscription usage
    const subscriptionUsage = await ctx.db
      .query("subscriptionUsage")
      .withIndex("by_clerk_user", (q) => q.eq("clerkId", user.clerkId))
      .first();
    
    if (!subscriptionUsage) {
      throw new Error("No subscription found for this user");
    }
    
    // Check if feature is allowed in the subscription
    if (subscriptionUsage.features && 
        !subscriptionUsage.features.includes(args.feature)) {
      throw new Error(`Feature ${args.feature} not available in your subscription`);
    }
    
    const now = Date.now();
    
    // Update the usage
    let usage = {};
    try {
      usage = subscriptionUsage.usage || {};
    } catch (e) {
      usage = {};
    }
    
    // Initialize feature if not present
    if (!usage[args.feature]) {
      usage[args.feature] = {
        total: 0,
        history: []
      };
    }
    
    // Update total
    usage[args.feature].total += args.quantity;
    
    // Add to history (keep last 100 entries)
    usage[args.feature].history = [
      {
        timestamp: now,
        quantity: args.quantity
      },
      ...(usage[args.feature].history || []).slice(0, 99)
    ];
    
    // Save updated usage
    await ctx.db.patch(subscriptionUsage._id, {
      usage,
      updatedAt: now,
    });
    
    // Log the usage
    await ctx.db.insert("analyticsEvents", {
      userId: user.clerkId,
      eventType: "feature_usage",
      eventData: JSON.stringify({
        feature: args.feature,
        quantity: args.quantity,
      }),
      timestamp: now,
    });
    
    return { 
      success: true,
      newTotal: usage[args.feature].total
    };
  },
});

/**
 * Get subscription usage for a user (admin or self)
 */
export const getSubscriptionUsage = query({
  args: {
    clerkId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await requireAuth(ctx);
    
    let targetClerkId = user.clerkId;
    
    // If clerkId is provided, check if current user is admin
    if (args.clerkId && args.clerkId !== user.clerkId) {
      const isAdmin = user.role === "admin";
      if (!isAdmin) {
        throw new Error("Only admins can view other users' subscription usage");
      }
      targetClerkId = args.clerkId;
    }
    
    // Get the subscription usage
    const subscriptionUsage = await ctx.db
      .query("subscriptionUsage")
      .withIndex("by_clerk_user", (q) => q.eq("clerkId", targetClerkId))
      .first();
    
    if (!subscriptionUsage) {
      return null;
    }
    
    // Get the user details
    const userDetails = await ctx.db
      .query("users")
      .withIndex("by_clerk_id", (q) => q.eq("clerkId", targetClerkId))
      .first();
    
    return {
      ...subscriptionUsage,
      user: userDetails ? {
        name: userDetails.name,
        email: userDetails.email,
      } : null,
    };
  },
});

/**
 * Check if user has access to a specific feature
 */
export const checkFeatureAccess = query({
  args: {
    feature: v.string(),
  },
  handler: async (ctx, args) => {
    const user = await requireAuth(ctx);
    
    // Check if the feature is in user's features
    if (user.features && user.features.includes(args.feature)) {
      return { hasAccess: true };
    }
    
    // Get subscription usage for more detailed check
    const subscriptionUsage = await ctx.db
      .query("subscriptionUsage")
      .withIndex("by_clerk_user", (q) => q.eq("clerkId", user.clerkId))
      .first();
    
    // No subscription means no access
    if (!subscriptionUsage) {
      return { hasAccess: false, reason: "no_subscription" };
    }
    
    // Check subscription status
    if (subscriptionUsage.status !== "active") {
      return { 
        hasAccess: false, 
        reason: "inactive_subscription",
        status: subscriptionUsage.status
      };
    }
    
    // Check if feature is in subscription features
    if (!subscriptionUsage.features || !subscriptionUsage.features.includes(args.feature)) {
      return { 
        hasAccess: false, 
        reason: "feature_not_included",
        availableFeatures: subscriptionUsage.features || []
      };
    }
    
    // Check for usage limits (if applicable)
    const featureUsage = subscriptionUsage.usage && subscriptionUsage.usage[args.feature];
    if (featureUsage) {
      // This is a simplified check. In reality, you'd check against plan-specific limits
      const FEATURE_LIMITS = {
        "basic": { "downloads": 10, "exports": 5 },
        "premium": { "downloads": 100, "exports": 50 },
        "pro": { "downloads": 1000, "exports": 500 }
      };
      
      const plan = subscriptionUsage.plan || "basic";
      const limits = FEATURE_LIMITS[plan] || {};
      
      if (limits[args.feature] && featureUsage.total >= limits[args.feature]) {
        return {
          hasAccess: false,
          reason: "usage_limit_exceeded",
          current: featureUsage.total,
          limit: limits[args.feature]
        };
      }
    }
    
    // All checks passed
    return { hasAccess: true };
  },
});

/**
 * List all subscription plans (admin only)
 */
export const listSubscriptionPlans = query({
  args: {},
  handler: async (ctx) => {
    await requireAdmin(ctx);
    
    // In a real implementation, you would query Clerk Billing API
    // This is a placeholder implementation with hardcoded plans
    return [
      {
        id: "basic",
        name: "Basic Plan",
        description: "Access to essential features",
        price: 9.99,
        interval: "month",
        features: ["core_content", "basic_playlists"],
        limits: {
          downloads: 10,
          exports: 5,
          storage: 1000000000 // 1GB in bytes
        }
      },
      {
        id: "premium",
        name: "Premium Plan",
        description: "Enhanced features and more content",
        price: 19.99,
        interval: "month",
        features: ["core_content", "premium_content", "advanced_playlists", "downloads"],
        limits: {
          downloads: 100,
          exports: 50,
          storage: 10000000000 // 10GB in bytes
        }
      },
      {
        id: "pro",
        name: "Professional Plan",
        description: "Full access to all features and content",
        price: 29.99,
        interval: "month",
        features: ["core_content", "premium_content", "advanced_playlists", "downloads", "exports", "api_access"],
        limits: {
          downloads: 1000,
          exports: 500,
          storage: 100000000000 // 100GB in bytes
        }
      }
    ];
  },
});
