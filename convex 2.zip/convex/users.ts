import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getUser, requireAdmin, requireAuth } from "./auth";

/**
 * Get the current authenticated user
 */
export const me = query({
  handler: async (ctx) => {
    return await getUser(ctx);
  },
});

/**
 * Store or update a user from Clerk
 */
export const storeUser = mutation({
  args: {
    clerkId: v.string(),
    tokenIdentifier: v.string(),
    email: v.string(),
    name: v.optional(v.string()),
    avatarUrl: v.optional(v.string()),
    role: v.union(v.literal("admin"), v.literal("subscriber")),
  },
  handler: async (ctx, args) => {
    // Look for existing user
    const existingUser = await ctx.db
      .query("users")
      .withIndex("by_clerk_id", (q) => q.eq("clerkId", args.clerkId))
      .first();

    const now = Date.now();

    if (existingUser) {
      // Update existing user
      return await ctx.db.patch(existingUser._id, {
        tokenIdentifier: args.tokenIdentifier,
        email: args.email,
        name: args.name,
        avatarUrl: args.avatarUrl,
        lastActiveAt: now,
        updatedAt: now,
      });
    } else {
      // Create new user
      return await ctx.db.insert("users", {
        clerkId: args.clerkId,
        tokenIdentifier: args.tokenIdentifier,
        email: args.email,
        name: args.name,
        avatarUrl: args.avatarUrl,
        role: args.role,
        lastActiveAt: now,
        createdAt: now,
        updatedAt: now,
      });
    }
  },
});

/**
 * Update user role (admin only)
 */
export const updateUserRole = mutation({
  args: {
    userId: v.id("users"),
    role: v.union(v.literal("admin"), v.literal("subscriber")),
  },
  handler: async (ctx, args) => {
    // Require admin authentication
    await requireAdmin(ctx);

    // Update user role
    return await ctx.db.patch(args.userId, {
      role: args.role,
      updatedAt: Date.now(),
    });
  },
});

/**
 * List users with pagination (admin only)
 */
export const listUsers = query({
  args: {
    role: v.optional(v.union(v.literal("admin"), v.literal("subscriber"))),
    limit: v.optional(v.number()),
    cursor: v.optional(v.id("users")),
  },
  handler: async (ctx, args) => {
    // Require admin authentication
    await requireAdmin(ctx);

    // Start the query
    let query = ctx.db.query("users");

    // Filter by role if specified
    if (args.role) {
      query = query.withIndex("by_role", (q) => q.eq("role", args.role));
    } else {
      query = query.withIndex("by_role_created", (q) => q.gt("role", ""));
    }

    // Apply pagination
    const limit = args.limit ?? 10;
    if (args.cursor) {
      query = query.order("desc").cursor(args.cursor);
    } else {
      query = query.order("desc");
    }

    // Execute the query
    const users = await query.take(limit + 1);

    // Check if there are more results
    const hasMore = users.length > limit;
    if (hasMore) {
      users.pop(); // Remove the extra item
    }

    // Return the results with pagination info
    return {
      users,
      hasMore,
      cursor: hasMore ? users[users.length - 1]._id : null,
    };
  },
});

/**
 * Get user by ID (admin only)
 */
export const getUserById = query({
  args: {
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    // Require admin authentication
    await requireAdmin(ctx);

    return await ctx.db.get(args.userId);
  },
});

/**
 * Update user's last active timestamp
 */
export const updateLastActive = mutation({
  handler: async (ctx) => {
    const user = await requireAuth(ctx);
    if (!user) return null;

    return await ctx.db.patch(user._id, {
      lastActiveAt: Date.now(),
    });
  },
});
