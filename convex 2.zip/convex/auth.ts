import { ConvexError, v } from "convex/values";
import { MutationCtx, QueryCtx } from "./_generated/server";

/**
 * Common authentication utility functions for Realigna app
 * Integrates with Clerk for user authentication and management
 */

/**
 * Get the current authenticated user from the request
 * @param ctx Convex context (query or mutation)
 * @returns User object if authenticated, null otherwise
 */
export async function getUser(ctx: QueryCtx | MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) {
    return null;
  }

  // Find the user with this identity
  const user = await ctx.db
    .query("users")
    .withIndex("by_token_identifier", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .first();
  
  return user;
}

/**
 * Require authentication for protected routes
 * @param ctx Convex context (query or mutation)
 * @returns User object
 * @throws ConvexError if not authenticated
 */
export async function requireAuth(ctx: QueryCtx | MutationCtx) {
  const user = await getUser(ctx);
  if (!user) {
    throw new ConvexError({ code: 401, message: "Not authenticated" });
  }
  return user;
}

/**
 * Require admin authentication
 * @param ctx Convex context (query or mutation)
 * @returns User object with admin role
 * @throws ConvexError if not authenticated or not an admin
 */
export async function requireAdmin(ctx: QueryCtx | MutationCtx) {
  const user = await requireAuth(ctx);
  
  if (user.role !== "admin") {
    throw new ConvexError({ 
      code: 403, 
      message: "Unauthorized access: Admin role required" 
    });
  }
  
  return user;
}

/**
 * Checks if a user has a specific permission
 * @param user The user object
 * @param permission Permission to check
 * @returns True if user has permission, false otherwise
 */
export function hasPermission(
  user: { role: string; permissions?: string[] },
  permission: string
) {
  // Admin role has all permissions
  if (user.role === "admin") return true;
  
  // Check if the user has the specific permission
  return user.permissions?.includes(permission) ?? false;
}
