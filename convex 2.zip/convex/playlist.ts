import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { requireAdmin, requireAuth } from "./auth";

/**
 * Create a new playlist category (admin only)
 */
export const createCategory = mutation({
  args: {
    name: v.string(),
    description: v.optional(v.string()),
    slug: v.string(),
    isActive: v.boolean(),
    order: v.number(),
    color: v.optional(v.string()),
    iconUrl: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    const now = Date.now();

    // Check if slug is unique
    const existingCategory = await ctx.db
      .query("coreCategories")
      .withIndex("by_slug", (q) => q.eq("slug", args.slug))
      .first();

    if (existingCategory) {
      throw new Error("A category with this slug already exists");
    }

    return await ctx.db.insert("coreCategories", {
      ...args,
      createdAt: now,
      updatedAt: now,
    });
  },
});

/**
 * Update a playlist category (admin only)
 */
export const updateCategory = mutation({
  args: {
    categoryId: v.id("coreCategories"),
    name: v.optional(v.string()),
    description: v.optional(v.string()),
    slug: v.optional(v.string()),
    isActive: v.optional(v.boolean()),
    order: v.optional(v.number()),
    color: v.optional(v.string()),
    iconUrl: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    const { categoryId, ...updates } = args;

    // If slug is being updated, check if it's unique
    if (updates.slug) {
      const existingCategory = await ctx.db
        .query("coreCategories")
        .withIndex("by_slug", (q) => q.eq("slug", updates.slug))
        .filter((q) => q.neq(q.field("_id"), categoryId))
        .first();

      if (existingCategory) {
        throw new Error("A category with this slug already exists");
      }
    }

    return await ctx.db.patch(categoryId, {
      ...updates,
      updatedAt: Date.now(),
    });
  },
});

/**
 * List all categories with optional filters
 */
export const listCategories = query({
  args: {
    activeOnly: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    await requireAuth(ctx);

    let query = ctx.db.query("coreCategories");

    if (args.activeOnly) {
      query = query.withIndex("by_active", (q) => q.eq("isActive", true));
    }

    return await query.withIndex("by_order", (q) => q.gt("order", -1))
      .collect();
  },
});

/**
 * Create a new playlist (admin only)
 */
export const createPlaylist = mutation({
  args: {
    title: v.string(),
    description: v.optional(v.string()),
    thumbnailUrl: v.optional(v.string()),
    status: v.union(v.literal("draft"), v.literal("published")),
    categoryId: v.id("coreCategories"),
    tags: v.optional(v.array(v.string())),
    difficulty: v.optional(v.union(
      v.literal("beginner"),
      v.literal("intermediate"),
      v.literal("advanced")
    )),
  },
  handler: async (ctx, args) => {
    const user = await requireAdmin(ctx);

    const now = Date.now();

    // Calculate publishing date if status is published
    const publishedAt = args.status === "published" ? now : undefined;

    return await ctx.db.insert("corePlaylists", {
      ...args,
      playCount: 0,
      createdBy: user.clerkId,
      publishedAt,
      createdAt: now,
      updatedAt: now,
    });
  },
});

/**
 * Update a playlist (admin only)
 */
export const updatePlaylist = mutation({
  args: {
    playlistId: v.id("corePlaylists"),
    title: v.optional(v.string()),
    description: v.optional(v.string()),
    thumbnailUrl: v.optional(v.string()),
    status: v.optional(v.union(v.literal("draft"), v.literal("published"))),
    categoryId: v.optional(v.id("coreCategories")),
    tags: v.optional(v.array(v.string())),
    difficulty: v.optional(v.union(
      v.literal("beginner"),
      v.literal("intermediate"),
      v.literal("advanced")
    )),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    const { playlistId, ...updates } = args;

    const playlist = await ctx.db.get(playlistId);
    if (!playlist) {
      throw new Error("Playlist not found");
    }

    const now = Date.now();

    // If status is changing to published, set publishedAt
    if (updates.status === "published" && playlist.status !== "published") {
      updates.publishedAt = now;
    }

    return await ctx.db.patch(playlistId, {
      ...updates,
      updatedAt: now,
    });
  },
});

/**
 * Delete a playlist (admin only)
 */
export const deletePlaylist = mutation({
  args: {
    playlistId: v.id("corePlaylists"),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    // Check if playlist has sections
    const sections = await ctx.db
      .query("coreSections")
      .withIndex("by_playlist", (q) => q.eq("playlistId", args.playlistId))
      .collect();

    if (sections.length > 0) {
      // Delete all sections first
      for (const section of sections) {
        // Delete section media associations
        const sectionMedias = await ctx.db
          .query("sectionMedias")
          .withIndex("by_section", (q) => q.eq("sectionId", section._id))
          .collect();

        for (const sectionMedia of sectionMedias) {
          await ctx.db.delete(sectionMedia._id);
        }

        // Delete the section
        await ctx.db.delete(section._id);
      }
    }

    // Delete subscriber playlists related to this core playlist
    const subscriberPlaylists = await ctx.db
      .query("subscriberPlaylists")
      .withIndex("by_core_playlist", (q) => q.eq("corePlaylistId", args.playlistId))
      .collect();

    for (const subscriberPlaylist of subscriberPlaylists) {
      // Delete media selections for this subscriber playlist
      const selections = await ctx.db
        .query("subscriberMediaSelections")
        .withIndex("by_subscriber_playlist", (q) =>
          q.eq("subscriberPlaylistId", subscriberPlaylist._id)
        )
        .collect();

      for (const selection of selections) {
        await ctx.db.delete(selection._id);
      }

      // Delete the subscriber playlist
      await ctx.db.delete(subscriberPlaylist._id);
    }

    // Finally delete the playlist itself
    await ctx.db.delete(args.playlistId);

    return { success: true };
  },
});

/**
 * Get a playlist by ID
 */
export const getPlaylistById = query({
  args: {
    playlistId: v.id("corePlaylists"),
  },
  handler: async (ctx, args) => {
    await requireAuth(ctx);

    const playlist = await ctx.db.get(args.playlistId);

    if (!playlist) {
      return null;
    }

    // Get the category
    const category = playlist.categoryId
      ? await ctx.db.get(playlist.categoryId)
      : null;

    // Get sections count
    const sectionsCount = await ctx.db
      .query("coreSections")
      .withIndex("by_playlist", (q) => q.eq("playlistId", args.playlistId))
      .count();

    // Return the playlist with additional information
    return {
      ...playlist,
      category,
      sectionsCount,
    };
  },
});

/**
 * List playlists with pagination
 */
export const listPlaylists = query({
  args: {
    status: v.optional(v.union(v.literal("draft"), v.literal("published"))),
    categoryId: v.optional(v.id("coreCategories")),
    limit: v.optional(v.number()),
    cursor: v.optional(v.id("corePlaylists")),
    createdBy: v.optional(v.string()), // Clerk user ID
  },
  handler: async (ctx, args) => {
    await requireAuth(ctx);

    let query = ctx.db.query("corePlaylists");

    // Apply filters
    if (args.status && args.categoryId) {
      query = query.withIndex("by_category_status", (q) =>
        q.eq("categoryId", args.categoryId).eq("status", args.status)
      );
    } else if (args.status) {
      query = query.withIndex("by_status", (q) => q.eq("status", args.status));
    } else if (args.categoryId) {
      query = query.withIndex("by_category", (q) => q.eq("categoryId", args.categoryId));
    } else if (args.createdBy) {
      query = query.withIndex("by_creator", (q) => q.eq("createdBy", args.createdBy));
    } else {
      // Default to sorting by updatedAt
      query = query.withIndex("by_status_updated", (q) => q.gt("status", ""));
    }

    // Apply pagination
    const limit = args.limit ?? 10;
    if (args.cursor) {
      query = query.order("desc").cursor(args.cursor);
    } else {
      query = query.order("desc");
    }

    // Execute the query
    const playlists = await query.take(limit + 1);

    // Check if there are more results
    const hasMore = playlists.length > limit;
    if (hasMore) {
      playlists.pop(); // Remove the extra item
    }

    // Get categories for all playlists
    const categoryIds = [...new Set(playlists.map(p => p.categoryId).filter(Boolean))];
    const categories = categoryIds.length > 0
      ? await Promise.all(categoryIds.map(id => ctx.db.get(id)))
      : [];

    // Build a map of category IDs to categories for easier lookup
    const categoryMap = Object.fromEntries(
      categories.map(cat => [cat!._id, cat])
    );

    // Enhance playlists with category info
    const enhancedPlaylists = playlists.map(playlist => ({
      ...playlist,
      category: playlist.categoryId ? categoryMap[playlist.categoryId] : null,
    }));

    return {
      playlists: enhancedPlaylists,
      hasMore,
      cursor: hasMore ? playlists[playlists.length - 1]._id : null,
    };
  },
});
