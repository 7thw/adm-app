import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { requireAdmin, requireAuth } from "./auth";

/**
 * Create a new media item (admin only)
 */
export const createMedia = mutation({
  args: {
    title: v.string(),
    description: v.optional(v.string()),
    mediaType: v.union(v.literal("audio"), v.literal("video")),
    mediaUrl: v.string(),
    thumbnailUrl: v.optional(v.string()),
    duration: v.number(),
    fileSize: v.optional(v.number()),
    uploadKey: v.optional(v.string()),
    contentType: v.optional(v.string()),
    tags: v.optional(v.array(v.string())),
    transcript: v.optional(v.string()),
    waveformData: v.optional(v.string()),
    youtubeId: v.optional(v.string()),
    quality: v.optional(v.string()),
    bitrate: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const user = await requireAdmin(ctx);

    const now = Date.now();

    return await ctx.db.insert("medias", {
      ...args,
      uploadStatus: "completed",
      uploadedBy: user.clerkId,
      createdAt: now,
      updatedAt: now,
    });
  },
});

/**
 * Update an existing media item (admin only)
 */
export const updateMedia = mutation({
  args: {
    mediaId: v.id("medias"),
    title: v.optional(v.string()),
    description: v.optional(v.string()),
    mediaUrl: v.optional(v.string()),
    thumbnailUrl: v.optional(v.string()),
    duration: v.optional(v.number()),
    tags: v.optional(v.array(v.string())),
    transcript: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    const { mediaId, ...updates } = args;

    // Verify the media exists
    const media = await ctx.db.get(mediaId);
    if (!media) {
      throw new Error("Media not found");
    }

    return await ctx.db.patch(mediaId, {
      ...updates,
      updatedAt: Date.now(),
    });
  },
});

/**
 * Delete a media item (admin only)
 */
export const deleteMedia = mutation({
  args: {
    mediaId: v.id("medias"),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    // First check if this media is being used in any sections
    const usages = await ctx.db
      .query("sectionMedias")
      .withIndex("by_media", (q) => q.eq("mediaId", args.mediaId))
      .collect();

    if (usages.length > 0) {
      throw new Error("Cannot delete media that is being used in sections");
    }

    return await ctx.db.delete(args.mediaId);
  },
});

/**
 * Get a single media item by ID
 */
export const getMediaById = query({
  args: {
    mediaId: v.id("medias"),
  },
  handler: async (ctx, args) => {
    await requireAuth(ctx);

    return await ctx.db.get(args.mediaId);
  },
});

/**
 * List all media items with optional filters and pagination
 */
export const listMedia = query({
  args: {
    mediaType: v.optional(v.union(v.literal("audio"), v.literal("video"))),
    status: v.optional(v.union(
      v.literal("pending"),
      v.literal("processing"),
      v.literal("completed"),
      v.literal("failed")
    )),
    limit: v.optional(v.number()),
    cursor: v.optional(v.id("medias")),
    tags: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    await requireAuth(ctx);

    let query = ctx.db.query("medias");

    // Apply filters
    if (args.mediaType) {
      query = query.withIndex("by_type", (q) => q.eq("mediaType", args.mediaType));
    }

    if (args.status) {
      query = query.withIndex("by_status", (q) => q.eq("uploadStatus", args.status));
    }

    if (args.tags && args.tags.length > 0) {
      query = query.withIndex("by_tags", (q) => q.eq("tags", args.tags[0]));
      // Note: This only filters by the first tag. For multiple tags, we would need
      // additional filtering in-memory after fetching the results
    }

    // Apply pagination
    const limit = args.limit ?? 20;
    if (args.cursor) {
      query = query.order("desc").cursor(args.cursor);
    } else {
      query = query.order("desc");
    }

    // Execute the query
    const medias = await query.take(limit + 1);

    // Check if there are more results
    const hasMore = medias.length > limit;
    if (hasMore) {
      medias.pop(); // Remove the extra item
    }

    // Filter by additional tags if needed (in-memory filtering)
    let filteredMedias = medias;
    if (args.tags && args.tags.length > 1) {
      filteredMedias = medias.filter(media => {
        if (!media.tags) return false;
        return args.tags!.every(tag => media.tags!.includes(tag));
      });
    }

    return {
      medias: filteredMedias,
      hasMore: hasMore && filteredMedias.length === medias.length,
      cursor: hasMore ? medias[medias.length - 1]._id : null,
    };
  },
});

/**
 * Prepare a media upload with R2 storage
 */
export const generateUploadUrl = mutation({
  args: {
    filename: v.string(),
    contentType: v.string(),
    fileSize: v.number(),
  },
  handler: async (ctx, args) => {
    const user = await requireAdmin(ctx);

    // Generate a unique upload key
    const uploadKey = `${Date.now()}-${Math.random().toString(36).substring(2, 15)}`;

    // Create R2 file record
    const r2FileId = await ctx.db.insert("r2Files", {
      uploadKey,
      fileName: `${uploadKey}-${args.filename}`,
      originalName: args.filename,
      fileSize: args.fileSize,
      contentType: args.contentType,
      uploadStatus: "pending",
      uploadedBy: user.clerkId,
      uploadProgress: 0,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });

    // Create a placeholder media record
    const mediaId = await ctx.db.insert("medias", {
      title: args.filename,
      description: "",
      mediaType: args.contentType.startsWith("audio/") ? "audio" : "video",
      mediaUrl: "", // Will be updated after upload is complete
      duration: 0, // Will be updated after processing
      fileSize: args.fileSize,
      uploadKey,
      contentType: args.contentType,
      uploadStatus: "pending",
      uploadedBy: user.clerkId,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });

    // Update the R2 file with the media ID
    await ctx.db.patch(r2FileId, {
      mediaId,
    });

    // Get the storage upload URL (in a real implementation, this would generate a signed URL)
    // For now, we'll just return the upload key as a placeholder
    return {
      uploadUrl: "https://storage-upload-url-placeholder.com", // This would be a real signed URL
      uploadKey,
      mediaId,
      r2FileId,
    };
  },
});

/**
 * Update upload status
 */
export const updateUploadStatus = mutation({
  args: {
    uploadKey: v.string(),
    status: v.union(
      v.literal("pending"),
      v.literal("processing"),
      v.literal("completed"),
      v.literal("failed")
    ),
    progress: v.optional(v.number()),
    errorMessage: v.optional(v.string()),
    mediaUrl: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    const now = Date.now();

    // Update the R2 file status
    const r2File = await ctx.db
      .query("r2Files")
      .withIndex("by_upload_key", (q) => q.eq("uploadKey", args.uploadKey))
      .first();

    if (!r2File) {
      throw new Error("Upload not found");
    }

    await ctx.db.patch(r2File._id, {
      uploadStatus: args.status,
      uploadProgress: args.progress ?? r2File.uploadProgress,
      errorMessage: args.errorMessage,
      updatedAt: now,
    });

    // Update the media record if it exists
    if (r2File.mediaId) {
      const updates: any = {
        uploadStatus: args.status,
        updatedAt: now,
      };

      if (args.mediaUrl) {
        updates.mediaUrl = args.mediaUrl;
      }

      await ctx.db.patch(r2File.mediaId, updates);
    }

    return { success: true };
  },
});

/**
 * Search media by title or description
 */
export const searchMedia = query({
  args: {
    query: v.string(),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await requireAuth(ctx);

    // In a real implementation, you might want to use a proper search index
    // This is a simplified version that searches in memory
    const allMedia = await ctx.db
      .query("medias")
      .withIndex("by_created", (q) => q.gt("createdAt", 0))
      .order("desc")
      .take(100); // Cap the number of items to search through

    // Simple search by title or description
    const query = args.query.toLowerCase();
    const results = allMedia.filter(media => {
      return (
        media.title.toLowerCase().includes(query) ||
        (media.description && media.description.toLowerCase().includes(query))
      );
    });

    const limit = args.limit ?? 20;

    return results.slice(0, limit);
  },
});
