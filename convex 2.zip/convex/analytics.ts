import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { requireAdmin, requireAuth } from "./auth";

/**
 * Track user activity or app events
 */
export const trackEvent = mutation({
  args: {
    eventType: v.string(),
    eventData: v.string(), // JSON string of event data
    mediaId: v.optional(v.id("medias")),
    playlistId: v.optional(v.id("subscriberPlaylists")),
    sessionId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await requireAuth(ctx);
    
    await ctx.db.insert("analyticsEvents", {
      userId: user.clerkId,
      eventType: args.eventType,
      eventData: args.eventData,
      mediaId: args.mediaId,
      playlistId: args.playlistId,
      sessionId: args.sessionId,
      timestamp: Date.now(),
    });
    
    return { success: true };
  },
});

/**
 * Track system performance metrics
 */
export const trackPerformance = mutation({
  args: {
    metricName: v.string(),
    metricValue: v.number(),
    metricType: v.union(
      v.literal("timer"),
      v.literal("counter"),
      v.literal("gauge")
    ),
    tags: v.optional(v.array(v.string())),
    context: v.optional(v.string()), // JSON string of context data
  },
  handler: async (ctx, args) => {
    const user = await requireAuth(ctx);
    
    await ctx.db.insert("performanceMetrics", {
      userId: user.clerkId,
      metricName: args.metricName,
      metricValue: args.metricValue,
      metricType: args.metricType,
      tags: args.tags || [],
      context: args.context || "{}",
      timestamp: Date.now(),
    });
    
    return { success: true };
  },
});

/**
 * Log admin actions for auditing
 */
export const logAdminAction = mutation({
  args: {
    actionType: v.string(),
    actionDetail: v.string(),
    targetId: v.optional(v.string()),
    targetType: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await requireAdmin(ctx);
    
    await ctx.db.insert("adminActions", {
      adminId: user.clerkId,
      actionType: args.actionType,
      actionDetail: args.actionDetail,
      targetId: args.targetId,
      targetType: args.targetType,
      timestamp: Date.now(),
    });
    
    return { success: true };
  },
});

/**
 * Get user analytics data (admin only)
 */
export const getUserAnalytics = query({
  args: {
    userId: v.string(),
    startDate: v.number(),
    endDate: v.number(),
    eventTypes: v.optional(v.array(v.string())),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    let query = ctx.db.query("analyticsEvents")
      .withIndex("by_user_time", (q) => 
        q.eq("userId", args.userId)
          .gt("timestamp", args.startDate)
          .lt("timestamp", args.endDate)
      )
      .order("desc");
    
    if (args.eventTypes && args.eventTypes.length > 0) {
      query = query.filter((q) =>
        q.or(...args.eventTypes!.map(type => q.eq(q.field("eventType"), type)))
      );
    }
    
    const limit = args.limit || 100;
    const events = await query.take(limit);
    
    return events;
  },
});

/**
 * Get content analytics (admin only)
 */
export const getContentAnalytics = query({
  args: {
    mediaId: v.optional(v.id("medias")),
    playlistId: v.optional(v.id("corePlaylists")),
    startDate: v.number(),
    endDate: v.number(),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    let query = ctx.db.query("analyticsEvents")
      .withIndex("by_time", (q) => 
        q.gt("timestamp", args.startDate)
          .lt("timestamp", args.endDate)
      )
      .order("desc");
    
    if (args.mediaId) {
      query = query.filter((q) => q.eq(q.field("mediaId"), args.mediaId));
    }
    
    if (args.playlistId) {
      // Find all subscriber playlists derived from this core playlist
      const subscriberPlaylists = await ctx.db
        .query("subscriberPlaylists")
        .withIndex("by_core_playlist", (q) => q.eq("corePlaylistId", args.playlistId))
        .collect();
      
      const playlistIds = subscriberPlaylists.map(p => p._id);
      
      if (playlistIds.length > 0) {
        query = query.filter((q) =>
          q.or(...playlistIds.map(id => q.eq(q.field("playlistId"), id)))
        );
      }
    }
    
    const limit = args.limit || 100;
    const events = await query.take(limit);
    
    // Group events by type for analytics
    const eventsByType = {};
    for (const event of events) {
      if (!eventsByType[event.eventType]) {
        eventsByType[event.eventType] = [];
      }
      eventsByType[event.eventType].push(event);
    }
    
    // Calculate summary metrics
    const totalEvents = events.length;
    const uniqueUsers = new Set(events.map(e => e.userId)).size;
    
    // Calculate play metrics if applicable
    let totalPlayDuration = 0;
    let completionRates = [];
    
    if (eventsByType["media_play"]) {
      for (const playEvent of eventsByType["media_play"]) {
        try {
          const data = JSON.parse(playEvent.eventData);
          if (typeof data.duration === "number") {
            totalPlayDuration += data.duration;
          }
          if (typeof data.completionRate === "number") {
            completionRates.push(data.completionRate);
          }
        } catch (e) {
          // Skip invalid JSON
        }
      }
    }
    
    // Calculate average completion rate
    const avgCompletionRate = completionRates.length > 0
      ? completionRates.reduce((sum, rate) => sum + rate, 0) / completionRates.length
      : 0;
    
    return {
      events,
      summary: {
        totalEvents,
        uniqueUsers,
        totalPlayDuration,
        avgCompletionRate,
        eventTypeBreakdown: Object.fromEntries(
          Object.entries(eventsByType).map(([type, events]) => [type, events.length])
        ),
      },
    };
  },
});

/**
 * Get system performance metrics (admin only)
 */
export const getPerformanceMetrics = query({
  args: {
    metricName: v.optional(v.string()),
    metricType: v.optional(v.union(
      v.literal("timer"),
      v.literal("counter"),
      v.literal("gauge")
    )),
    startDate: v.number(),
    endDate: v.number(),
    tags: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    let query = ctx.db.query("performanceMetrics")
      .withIndex("by_time", (q) => 
        q.gt("timestamp", args.startDate)
          .lt("timestamp", args.endDate)
      )
      .order("desc");
    
    if (args.metricName) {
      query = query.filter((q) => q.eq(q.field("metricName"), args.metricName));
    }
    
    if (args.metricType) {
      query = query.filter((q) => q.eq(q.field("metricType"), args.metricType));
    }
    
    if (args.tags && args.tags.length > 0) {
      // Filter for metrics that contain at least one of the specified tags
      query = query.filter((q) => {
        const conditions = args.tags!.map(tag => 
          q.eq(q.field("tags").includes(tag), true)
        );
        return q.or(...conditions);
      });
    }
    
    const metrics = await query.collect();
    
    // Group metrics by name
    const metricsByName = {};
    for (const metric of metrics) {
      if (!metricsByName[metric.metricName]) {
        metricsByName[metric.metricName] = [];
      }
      metricsByName[metric.metricName].push(metric);
    }
    
    // Calculate summary for each metric
    const metricSummaries = {};
    for (const [name, values] of Object.entries(metricsByName)) {
      const metricValues = values.map(m => m.metricValue);
      
      metricSummaries[name] = {
        count: values.length,
        min: Math.min(...metricValues),
        max: Math.max(...metricValues),
        avg: metricValues.reduce((sum, val) => sum + val, 0) / metricValues.length,
        latest: values[0].metricValue,
      };
    }
    
    return {
      metrics,
      summary: metricSummaries,
    };
  },
});

/**
 * Get admin action logs (admin only)
 */
export const getAdminActions = query({
  args: {
    adminId: v.optional(v.string()),
    actionType: v.optional(v.string()),
    startDate: v.number(),
    endDate: v.number(),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    
    let query = ctx.db.query("adminActions")
      .withIndex("by_time", (q) => 
        q.gt("timestamp", args.startDate)
          .lt("timestamp", args.endDate)
      )
      .order("desc");
    
    if (args.adminId) {
      query = query.filter((q) => q.eq(q.field("adminId"), args.adminId));
    }
    
    if (args.actionType) {
      query = query.filter((q) => q.eq(q.field("actionType"), args.actionType));
    }
    
    const limit = args.limit || 100;
    const actions = await query.take(limit);
    
    // Enhance with admin user details
    const adminIds = [...new Set(actions.map(a => a.adminId))];
    
    const adminUsers = {};
    for (const adminId of adminIds) {
      const user = await ctx.db
        .query("users")
        .withIndex("by_clerk_id", (q) => q.eq("clerkId", adminId))
        .first();
        
      if (user) {
        adminUsers[adminId] = {
          name: user.name || user.email,
          email: user.email,
        };
      }
    }
    
    return {
      actions: actions.map(action => ({
        ...action,
        admin: adminUsers[action.adminId],
      })),
      total: actions.length,
    };
  },
});
