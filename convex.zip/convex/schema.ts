// convex/schema.ts
import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  // Main Users table - stores all users from Clerk with their role
  users: defineTable({
    id: v.id("users"),
    clerkId: v.string(), // Clerk's user ID as a string (not a Convex ID)
    tokenIdentifier: v.string(), // Clerk's token identifier for auth
    // Role-based access control
    role: v.union(v.literal("admin"), v.literal("subscriber")),
    // Permissions array for fine-grained access control
    permissions: v.optional(v.array(v.string())),
    // Subscription plan from Clerk Billing
    plan: v.optional(v.string()), // e.g., "free", "basic", "premium", "gold"
    // Features available to this user (from Clerk)
    features: v.optional(v.array(v.string())), // e.g., ["download", "hd_streaming", "offline_access"]
    // Standard user information
    email: v.string(),
    firstName: v.optional(v.string()),
    lastName: v.optional(v.string()),
    imageUrl: v.optional(v.string()),
    name: v.optional(v.string()),
    // Additional metadata
    metadata: v.optional(v.any()),
    lastLogin: v.optional(v.number()),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_clerk_id", ["clerkId"]) // Index for looking up by Clerk ID
    .index("by_token_identifier", ["tokenIdentifier"]) // Changed from by_token to match code
    .index("by_email", ["email"])
    .index("by_role", ["role"])
    .index("by_plan", ["plan"]), // Index for filtering by subscription plan

  // Admin Users - extended data specific to admin role
  adminProfiles: defineTable({
    id: v.id("adminProfiles"),
    userId: v.id("users"), // Reference to the main users table
    clerkId: v.string(), // Clerk's user ID as a string for easier querying

    // Clerk authorization integration
    // Fine-grained permissions for admin actions
    permissions: v.array(v.string()), // e.g., ["manage_users", "edit_content", "view_analytics"]
    adminRole: v.union(
      v.literal("super_admin"),
      v.literal("content_manager"),
      v.literal("analyst")
    ),

    // Admin organization membership
    organizationId: v.optional(v.string()), // Clerk organization ID
    organizationRole: v.optional(v.string()), // Role within the organization

    // Admin-specific settings
    adminSettings: v.optional(v.object({
      dashboardView: v.optional(v.string()),
      notifications: v.optional(v.boolean()),
      theme: v.optional(v.string()),
      defaultFilters: v.optional(v.any()),
      // Add other admin-specific settings as needed
    })),

    // Activity tracking
    lastAdminAction: v.optional(v.number()),
    actionHistory: v.optional(v.array(v.object({
      action: v.string(),
      timestamp: v.number(),
      details: v.optional(v.any())
    }))),

    // Standard timestamps
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_user_id", ["userId"])
    .index("by_clerk_id", ["clerkId"])
    .index("by_admin_role", ["adminRole"])
    .index("by_organization_id", ["organizationId"]),

  // Medias (uploaded/embedded content)
  medias: defineTable({
    id: v.id("medias"),
    title: v.string(),
    description: v.optional(v.string()),
    mediaType: v.union(v.literal("audio"), v.literal("video")),
    mediaUrl: v.string(), // CloudFlare R2 URL for audio, YouTube URL for video
    thumbnailUrl: v.optional(v.string()),
    duration: v.optional(v.number()), // in seconds
    fileSize: v.optional(v.number()), // in bytes, for audio files
    uploadKey: v.optional(v.string()), // R2 key for audio files
    contentType: v.optional(v.string()), // MIME type of the file
    userId: v.optional(v.string()), // User who uploaded the file
    uploadStatus: v.optional(v.union(
      v.literal("pending"),
      v.literal("completed"),
      v.literal("failed")
    )),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_type", ["mediaType"])
    .index("by_upload_status", ["uploadStatus"])
    .index("by_created", ["createdAt"]),

  // CoreCategories (for tagging)
  coreCategories: defineTable({
    id: v.id("coreCategories"),
    title: v.string(),
    description: v.optional(v.string()),
    isActive: v.boolean(),
    order: v.number(),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_order", ["order"])
    .index("by_active", ["isActive"]),

  // CorePlaylists
  corePlaylists: defineTable({
    title: v.string(),
    description: v.optional(v.string()),
    thumbnailUrl: v.optional(v.string()),
    status: v.union(v.literal("draft"), v.literal("published")),
    categoryId: v.id("coreCategories"),
    totalDuration: v.optional(v.number()), // calculated total duration
    playCount: v.number(),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_status", ["status"])
    .index("by_category", ["categoryId"])
    .index("by_published", ["status", "createdAt"])
    .index("by_play_count", ["playCount"]),

  // CoreSections
  coreSections: defineTable({
    id: v.id("coreSections"),
    corePlaylistId: v.id("corePlaylists"),
    title: v.string(),
    description: v.optional(v.string()),
    sectionType: v.union(v.literal("base"), v.literal("loop")),
    minSelectMedia: v.number(), // minimum medias subscribers must toggle on
    maxSelectMedia: v.number(), // maximum medias subscribers can toggle on
    coreSectionOrder: v.number(),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_core_playlist", ["corePlaylistId"])
    .index("by_core_playlist_order", ["corePlaylistId", "coreSectionOrder"]),

  // CoreSection Medias (linking media to sections)
  coreSectionMedias: defineTable({
    id: v.id("coreSectionMedias"),
    sectionId: v.id("coreSections"),
    mediasId: v.id("medias"), // list of media ids
    mediasTitle: v.string(), // list of media titles
    order: v.number(),
    isRequired: v.optional(v.boolean()), // if true, this media is always selected
    createdAt: v.number(),
  })
    .index("by_section", ["sectionId"])
    .index("by_section_order", ["sectionId", "order"])
    .index("by_media", ["mediasId"]),

  // SUBSCRIBER

  // Users (managed by Clerk)
  // Subscriber Profiles - extended data specific to subscribers
  subscriberProfiles: defineTable({
    id: v.id("subscriberProfiles"),
    userId: v.id("users"), // Reference to the main users table
    clerkId: v.string(), // Clerk's user ID as a string for easier querying

    // Clerk Billing integration
    // Subscription information
    subscriptionStatus: v.union(
      v.literal("active"),
      v.literal("inactive"),
      v.literal("cancelled"),
      v.literal("past_due")
    ),
    subscriptionPlan: v.optional(v.string()), // e.g., "free", "basic", "premium", "gold"
    subscriptionId: v.optional(v.string()), // Clerk subscription ID
    subscriptionStartDate: v.optional(v.number()),
    subscriptionEndDate: v.optional(v.number()),
    billingCycleStart: v.optional(v.number()),
    billingCycleEnd: v.optional(v.number()),
    paymentMethod: v.optional(v.string()),

    // Entitlements from Clerk
    entitlements: v.optional(v.array(v.string())), // Features the user is entitled to

    // Subscriber-specific settings
    subscriberSettings: v.optional(v.object({
      preferredCategories: v.optional(v.array(v.id("coreCategories"))),
      notifications: v.optional(v.boolean()),
      theme: v.optional(v.string()),
      // Add other subscriber-specific settings as needed
    })),

    // Activity tracking
    lastActivity: v.optional(v.number()),
    watchHistory: v.optional(v.array(v.id("medias"))),
    watchedSeconds: v.optional(v.number()), // Total seconds of content watched
    favoriteMedias: v.optional(v.array(v.id("medias"))),
    favoritePlaylists: v.optional(v.array(v.id("corePlaylists"))),

    // Standard timestamps
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_user_id", ["userId"])
    .index("by_clerk_id", ["clerkId"])
    .index("by_subscription_status", ["subscriptionStatus"])
    .index("by_subscription_plan", ["subscriptionPlan"]),

  // SubscriberPlaylists (customized core-playlists by subscribers)
  subscriberPlaylists: defineTable({
    id: v.id("subscriberPlaylists"),
    userId: v.string(), // Clerk user id
    subscriberUserId: v.id("subscriberUsers"),
    corePlaylistId: v.id("corePlaylists"),
    corePlaylistTitle: v.string(),
    corePlaylistStatus: v.string(),
    corePlaylistCategory: v.string(),
    corePlaylistDescription: v.string(),
    corePlaylistThumbnailUrl: v.string(),
    corePlaylistTotalDuration: v.number(),
    corePlaylistPlayCount: v.number(),
    corePlaylistCreatedAt: v.number(),
    corePlaylistUpdatedAt: v.number(),
    playCount: v.number(),
    isActive: v.boolean(),
    updatedAt: v.number(),
    lastSync: v.number(),
    lastPlayed: v.optional(v.number()),
  })
    .index("by_subscriber_user", ["subscriberUserId"])
    .index("by_subscriber_user_active", ["subscriberUserId", "isActive"])
    .index("by_core_playlist", ["corePlaylistId"])
    .index("by_last_played", ["lastPlayed"]),

  // SubscriberMediaSelection (tracks which media subscriber selected per section)
  subscriberMediaSelections: defineTable({
    subscriberPlaylistId: v.id("subscriberPlaylists"),
    sectionId: v.id("coreSections"),
    mediasId: v.id("media"),
    isSelected: v.boolean(),
    playOrder: v.optional(v.number()),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_subscriber_playlist", ["subscriberPlaylistId"])
    .index("by_section", ["sectionId"])
    .index("by_media", ["mediasId"])
    .index("by_selection", ["subscriberPlaylistId", "sectionId", "isSelected"]),

  // SubscriberSettings (for PWA offline storage reference)
  subscriberSettings: defineTable({
    userId: v.string(), // Clerk user id
    preferences: v.object({
      autoSync: v.boolean(),
      offlineMode: v.boolean(),
      downloadQuality: v.optional(v.union(
        v.literal("low"),
        v.literal("medium"),
        v.literal("high")
      )),
      maxStorageSize: v.optional(v.number()), // MB
    }),
    offlineData: v.optional(v.string()), // JSON string of offline cached playlists
    lastSync: v.optional(v.number()),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_last_sync", ["lastSync"]),

  // SubscriberPlayerSettings
  subscriberPlayerSettings: defineTable({
    userId: v.string(), // Clerk user id
    playerSettings: v.object({
      maxLoop: v.number(), // 0, 1, 2, 3, or -1 for infinite
      countDownTimer: v.number(), // minutes
      volume: v.number(), // 0-100
      autoplay: v.optional(v.boolean()),
      shuffle: v.optional(v.boolean()),
    }),
    currentPlaylistId: v.optional(v.id("subscriberPlaylists")),
    currentMediaId: v.optional(v.id("media")),
    currentTime: v.number(), // current playback time in seconds
    lastActivity: v.number(), // timestamp of last activity
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_last_activity", ["lastActivity"]),

  // Analytics and Tracking
  subscriberPlayHistory: defineTable({
    userId: v.string(),
    mediaId: v.id("media"),
    subscriberPlaylistId: v.optional(v.id("subscriberPlaylists")),
    duration: v.number(), // how long they listened
    completionRate: v.number(), // percentage completed (0-100)
    timestamp: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_media", ["mediaId"])
    .index("by_timestamp", ["timestamp"])
    .index("by_user_timestamp", ["userId", "timestamp"]),

  // System notifications and announcements
  notifications: defineTable({
    title: v.string(),
    message: v.string(),
    type: v.union(
      v.literal("info"),
      v.literal("warning"),
      v.literal("error"),
      v.literal("success")
    ),
    targetAudience: v.union(
      v.literal("all"),
      v.literal("admins"),
      v.literal("subscribers")
    ),
    isActive: v.boolean(),
    expiresAt: v.optional(v.number()),
    createdAt: v.number(),
  })
    .index("by_active", ["isActive"])
    .index("by_target", ["targetAudience"])
    .index("by_expires", ["expiresAt"]),

  // Messages
  messages: defineTable({
    user: v.string(),
    message: v.string(),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_user", ["user"]),

  //end SUBSCRIBER


});
