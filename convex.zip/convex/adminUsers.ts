import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

// Admin-only function to get current admin user
export const getAdminUser = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return null;

    // First find the user in the main users table
    const user = await ctx.db
      .query("users")
      .withIndex("by_token_identifier", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .first();

    if (!user || user.role !== "admin") {
      throw new Error("Unauthorized: Admin access required");
    }

    // Get the admin profile with extended information
    const adminProfile = await ctx.db
      .query("adminProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", user._id))
      .first();

    // Return combined user data with admin profile
    return { ...user, profile: adminProfile };
  },
});

// Admin-only function to get all users
export const getAllUsers = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Unauthenticated");

    // Check if user is an admin
    const user = await ctx.db
      .query("users")
      .withIndex("by_token_identifier", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .first();

    if (!user || user.role !== "admin") {
      throw new Error("Unauthorized: Admin access required");
    }

    // Return all users (admin only)
    return await ctx.db.query("users").collect();
  },
});

// Admin-only function to create an admin user
export const storeAdminUser = mutation({
  args: {
    email: v.optional(v.string()),
    firstName: v.optional(v.string()),
    lastName: v.optional(v.string()),
    adminRole: v.optional(v.string()),
    permissions: v.optional(v.array(v.string())),
    organizationId: v.optional(v.string()),
    organizationRole: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new Error("Called storeAdminUser without authentication present");
    }

    const { email, firstName, lastName, adminRole, permissions, organizationId, organizationRole } = args;

    // Check if we've already stored this identity before in the users table
    const existingUser = await ctx.db
      .query("users")
      .withIndex("by_token_identifier", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier),
      )
      .unique();

    if (existingUser !== null) {
      // If we've seen this identity before, update the user data
      const updates: any = {};
      
      // Only update fields that are provided and different
      if (firstName && existingUser.firstName !== firstName) updates.firstName = firstName;
      if (lastName && existingUser.lastName !== lastName) updates.lastName = lastName;
      if (email && existingUser.email !== email) updates.email = email;
      
      // Ensure the user has admin role
      if (existingUser.role !== "admin") updates.role = "admin";
      
      // Apply updates if there are any
      if (Object.keys(updates).length > 0) {
        await ctx.db.patch(existingUser._id, updates);
      }
      
      // Check if admin profile exists
      const existingProfile = await ctx.db
        .query("adminProfiles")
        .withIndex("by_user_id", (q) => q.eq("userId", existingUser._id))
        .unique();
      
      if (existingProfile) {
        // Update admin profile
        const profileUpdates: any = { updatedAt: Date.now() };
        
        if (adminRole) profileUpdates.adminRole = adminRole;
        if (permissions) profileUpdates.permissions = permissions;
        if (organizationId) profileUpdates.organizationId = organizationId;
        if (organizationRole) profileUpdates.organizationRole = organizationRole;
        
        if (Object.keys(profileUpdates).length > 1) { // > 1 because updatedAt is always included
          await ctx.db.patch(existingProfile._id, profileUpdates);
        }
        
        return existingUser._id;
      } else {
        // Create new admin profile
        const adminProfileId = await ctx.db.insert("adminProfiles", {
          userId: existingUser._id,
          clerkId: identity.subject,
          adminRole: adminRole || "content_manager",
          permissions: permissions || ["view_dashboard", "edit_content"],
          organizationId,
          organizationRole,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        } as any);
        
        return existingUser._id;
      }
    } else {
      // Create new user in the users table
      const userId = await ctx.db.insert("users", {
        clerkId: identity.subject,
        tokenIdentifier: identity.tokenIdentifier,
        email: email || identity.email,
        firstName: firstName || identity.firstName || "",
        lastName: lastName || identity.lastName || "",
        role: "admin",
        createdAt: Date.now(),
        updatedAt: Date.now(),
      } as any);
      
      // Create admin profile
      const adminProfileId = await ctx.db.insert("adminProfiles", {
        userId,
        clerkId: identity.subject,
        adminRole: adminRole || "content_manager",
        permissions: permissions || ["view_dashboard", "edit_content"],
        organizationId,
        organizationRole,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      } as any);
      
      return userId;
    }
  },
});
