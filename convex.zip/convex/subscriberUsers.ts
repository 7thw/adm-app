import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

// Function accessible to subscribers to get their own user data with profile
export const getSubscriberUser = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return null;

    // Find the user in the main users table
    const user = await ctx.db
      .query("users")
      .withIndex("by_token_identifier", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .first();
    
    if (!user) return null;
    
    // Get the subscriber profile with extended information
    const subscriberProfile = await ctx.db
      .query("subscriberProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", user._id))
      .first();
    
    // Return combined user data with subscriber profile
    return { ...user, profile: subscriberProfile };
  },
});

// Function to create or update a subscriber user with Clerk integration
export const storeSubscriberUser = mutation({
  args: {
    email: v.optional(v.string()),
    firstName: v.optional(v.string()),
    lastName: v.optional(v.string()),
    subscriptionPlan: v.optional(v.string()),
    subscriptionId: v.optional(v.string()),
    entitlements: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new Error("Called storeSubscriberUser without authentication present");
    }

    const { email, firstName, lastName, subscriptionPlan, subscriptionId, entitlements } = args;

    // Check if we've already stored this identity in the users table
    const existingUser = await ctx.db
      .query("users")
      .withIndex("by_token_identifier", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier),
      )
      .unique();

    if (existingUser !== null) {
      // If we've seen this identity before, update the user data
      const updates: any = { updatedAt: Date.now() };
      
      // Only update fields that are provided and different
      if (firstName && existingUser.firstName !== firstName) updates.firstName = firstName;
      if (lastName && existingUser.lastName !== lastName) updates.lastName = lastName;
      if (email && existingUser.email !== email) updates.email = email;
      
      // Ensure the user has subscriber role
      if (existingUser.role !== "subscriber") updates.role = "subscriber";
      
      // Apply updates if there are any
      if (Object.keys(updates).length > 1) { // > 1 because updatedAt is always included
        await ctx.db.patch(existingUser._id, updates);
      }
      
      // Check if subscriber profile exists
      const existingProfile = await ctx.db
        .query("subscriberProfiles")
        .withIndex("by_user_id", (q) => q.eq("userId", existingUser._id))
        .unique();
      
      if (existingProfile) {
        // Update subscriber profile
        const profileUpdates: any = { updatedAt: Date.now() };
        
        // Update subscription information if provided
        if (subscriptionPlan) profileUpdates.subscriptionPlan = subscriptionPlan;
        if (subscriptionId) profileUpdates.subscriptionId = subscriptionId;
        if (entitlements) profileUpdates.entitlements = entitlements;
        
        // Update last activity
        profileUpdates.lastActivity = Date.now();
        
        if (Object.keys(profileUpdates).length > 1) { // > 1 because updatedAt is always included
          await ctx.db.patch(existingProfile._id, profileUpdates);
        }
        
        return existingUser._id;
      } else {
        // Create new subscriber profile
        const subscriberProfileId = await ctx.db.insert("subscriberProfiles", {
          userId: existingUser._id,
          clerkId: identity.subject,
          subscriptionStatus: "inactive", // Default status
          subscriptionPlan: subscriptionPlan || "free", // Default plan
          subscriptionId,
          entitlements: entitlements || [],
          lastActivity: Date.now(),
          createdAt: Date.now(),
          updatedAt: Date.now(),
        } as any);
        
        return existingUser._id;
      }
    } else {
      // Create new user in the users table
      const userId = await ctx.db.insert("users", {
        clerkId: identity.subject,
        tokenIdentifier: identity.tokenIdentifier,
        email: email || identity.email || "",
        firstName: firstName || identity.firstName || "",
        lastName: lastName || identity.lastName || "",
        imageUrl: identity.imageUrl,
        role: "subscriber",
        plan: subscriptionPlan || "free",
        features: entitlements || [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      } as any);
      
      // Create subscriber profile
      const subscriberProfileId = await ctx.db.insert("subscriberProfiles", {
        userId,
        clerkId: identity.subject,
        subscriptionStatus: "inactive", // Default status
        subscriptionPlan: subscriptionPlan || "free", // Default plan
        subscriptionId,
        entitlements: entitlements || [],
        lastActivity: Date.now(),
        createdAt: Date.now(),
        updatedAt: Date.now(),
      } as any);
      
      return userId;
    }
  },
});

// Function to get a subscriber user by ID (admin-only)
export const getSubscriberById = query({
  args: {
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const { userId } = args;
    
    // Check if caller is an admin
    const { isAdmin } = await import("./auth").then(m => m.requireAdmin(ctx, "getSubscriberById"));
    if (!isAdmin && process.env.NODE_ENV !== "production") {
      throw new Error("Admin access required");
    }
    
    // Get the user
    const user = await ctx.db.get(userId);
    if (!user || user.role !== "subscriber") return null;
    
    // Get the subscriber profile
    const subscriberProfile = await ctx.db
      .query("subscriberProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .first();
    
    // Return combined data
    return { ...user, profile: subscriberProfile };
  },
});

// Function to update subscriber subscription details (can be called from webhook)
export const updateSubscription = mutation({
  args: {
    clerkId: v.string(),
    subscriptionId: v.string(),
    subscriptionPlan: v.string(),
    subscriptionStatus: v.union(
      v.literal("active"),
      v.literal("inactive"),
      v.literal("cancelled"),
      v.literal("past_due")
    ),
    subscriptionStartDate: v.optional(v.number()),
    subscriptionEndDate: v.optional(v.number()),
    entitlements: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    const { clerkId, subscriptionId, subscriptionPlan, subscriptionStatus, 
           subscriptionStartDate, subscriptionEndDate, entitlements } = args;
    
    // Find the user by clerkId
    const user = await ctx.db
      .query("users")
      .withIndex("by_clerk_id", (q) => q.eq("clerkId", clerkId))
      .first();
    
    if (!user) {
      throw new Error(`User with clerkId ${clerkId} not found`);
    }
    
    // Update the user's plan and features
    await ctx.db.patch(user._id, {
      plan: subscriptionPlan,
      features: entitlements || [],
      updatedAt: Date.now(),
    });
    
    // Find and update the subscriber profile
    const subscriberProfile = await ctx.db
      .query("subscriberProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", user._id))
      .first();
    
    if (subscriberProfile) {
      // Update existing profile
      await ctx.db.patch(subscriberProfile._id, {
        subscriptionId,
        subscriptionPlan,
        subscriptionStatus,
        subscriptionStartDate: subscriptionStartDate || Date.now(),
        subscriptionEndDate,
        entitlements: entitlements || [],
        updatedAt: Date.now(),
      });
      
      return subscriberProfile._id;
    } else {
      // Create new profile if it doesn't exist
      return await ctx.db.insert("subscriberProfiles", {
        userId: user._id,
        clerkId,
        subscriptionId,
        subscriptionPlan,
        subscriptionStatus,
        subscriptionStartDate: subscriptionStartDate || Date.now(),
        subscriptionEndDate,
        entitlements: entitlements || [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      } as any);
    }
  },
});
