// convex/authClerk.ts - AUTH USING CLERK METADATA WITH OPTIONAL CONVEX TABLE LOOKUP
import { ConvexError } from "convex/values";
import { QueryCtx } from "./_generated/server";

// Define types for our user objects
type UserRecord = {
  _id: any;
  role: string;
  tokenIdentifier: string;
  [key: string]: any;
};

type AdminProfileRecord = {
  _id: any;
  userId: any;
  permissions: string[];
  [key: string]: any;
};

// Environment detection
const isDevelopment = process.env.NODE_ENV !== "production";

/**
 * Helper function to check if a user is authenticated
 */
export async function requireAuth(
  ctx: any, // More flexible typing to handle different context types
  functionName: string
) {
  const identity = await ctx.auth.getUserIdentity();

  if (!identity) {
    if (isDevelopment) {
      console.log(`⚠️ WARNING: Unauthenticated access to ${functionName} (allowed in development)`);
      return null;
    } else {
      throw new ConvexError("Not authenticated");
    }
  }

  return identity;
}

/**
 * Helper function to check if a user is an admin using CLERK METADATA
 * This checks Clerk's publicMetadata.role and optionally verifies against Convex tables
 */
export async function requireAdminClerk(
  ctx: any, // More flexible typing to handle different context types
  functionName: string,
  options = { checkConvexTables: false }
) {
  const identity = await requireAuth(ctx, functionName);

  // If we're in development and skipping auth checks
  if (!identity && isDevelopment) {
    return { isAdmin: true, identity: null, user: null, adminProfile: null };
  }

  if (!identity) {
    throw new ConvexError("Not authenticated");
  }

  console.log("🔍 Checking admin access for user:", {
    email: identity.email,
    subject: identity.subject,
    tokenIdentifier: identity.tokenIdentifier,
    publicMetadata: identity.publicMetadata,
    emailAddresses: identity.emailAddresses
  });

  // Check if the email matches the known admin email - try multiple fields
  const userEmail = identity.email || identity.emailAddresses?.[0]?.emailAddress
  const isKnownAdmin = userEmail === "adm-realigna@7thw.com"

  // Also check for role in Clerk metadata (if set)
  const clerkRole = (identity.publicMetadata as any)?.role
  const isAdminByRole = clerkRole === "admin"

  let isAdmin = isKnownAdmin || isAdminByRole;
  let user: UserRecord | null = null;
  let adminProfile: AdminProfileRecord | null = null;

  // Optionally check Convex tables for admin status
  if (options.checkConvexTables) {
    try {
      // Find the user in the users table
      user = await ctx.db
        .query("users")
        .withIndex("by_token_identifier", (q: any) => q.eq("tokenIdentifier", identity.tokenIdentifier))
        .first() as UserRecord | null;

      if (user && user.role === "admin") {
        // Get the admin profile
        // Extract userId to a constant to satisfy TypeScript's null check
        const userId = user._id;
        adminProfile = await ctx.db
          .query("adminProfiles")
          .withIndex("by_user_id", (q: any) => q.eq("userId", userId))
          .first() as AdminProfileRecord | null;

        if (adminProfile) {
          isAdmin = true;
        }
      }
    } catch (error) {
      console.error("Error checking Convex tables for admin status:", error);
      // Continue with Clerk metadata check only
    }
  }

  if (!isAdmin) {
    console.log("❌ Admin access denied:", {
      userEmail,
      isKnownAdmin,
      isAdminByRole,
      clerkRole,
      functionName,
      userInConvex: !!user,
      adminProfileInConvex: !!adminProfile
    });

    if (isDevelopment) {
      console.log(`⚠️ WARNING: Non-admin user accessing ${functionName} (allowed in development)`);
      return { isAdmin: true, identity, user, adminProfile }; // Allow in development
    } else {
      throw new ConvexError("Admin access required");
    }
  }

  console.log("✅ Admin access granted for:", userEmail);
  return { isAdmin: true, identity, user, adminProfile };
}

/**
 * Check if current user is admin (query version)
 */
export async function isCurrentUserAdmin(ctx: any, options = { checkConvexTables: false }) {
  const identity = await ctx.auth.getUserIdentity();

  if (!identity) {
    return { isAdmin: false, user: null, adminProfile: null };
  }

  // Check if the email matches the known admin email - try multiple fields
  const userEmail = identity.email || identity.emailAddresses?.[0]?.emailAddress
  const isKnownAdmin = userEmail === "adm-realigna@7thw.com"

  // Also check for role in Clerk metadata (if set)
  const clerkRole = (identity.publicMetadata as any)?.role
  const isAdminByRole = clerkRole === "admin"

  let isAdmin = isKnownAdmin || isAdminByRole;
  let user: UserRecord | null = null;
  let adminProfile: AdminProfileRecord | null = null;

  // Optionally check Convex tables for admin status
  if (options.checkConvexTables) {
    try {
      // Find the user in the users table
      user = await ctx.db
        .query("users")
        .withIndex("by_token_identifier", (q: any) => q.eq("tokenIdentifier", identity.tokenIdentifier))
        .first() as UserRecord | null;

      if (user && user.role === "admin") {
        // Get the admin profile
        // Extract userId to a constant to satisfy TypeScript's null check
        const userId = user._id;
        adminProfile = await ctx.db
          .query("adminProfiles")
          .withIndex("by_user_id", (q: any) => q.eq("userId", userId))
          .first() as AdminProfileRecord | null;

        if (adminProfile) {
          isAdmin = true;
        }
      }
    } catch (error) {
      console.error("Error checking Convex tables for admin status:", error);
      // Continue with Clerk metadata check only
    }
  }

  return { isAdmin, user, adminProfile };
}
