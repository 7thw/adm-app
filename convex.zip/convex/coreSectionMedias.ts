// convex/coreSectionMedias.ts
import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { requireAdminClerk, requireAuth } from "./authClerk";

// Get section media by section ID
export const getBySectionId = query({
  args: { sectionId: v.id("coreSections") },
  handler: async (ctx, { sectionId }) => {
    await requireAuth(ctx, "coreSectionMedias:getBySectionId");

    return await ctx.db
      .query("coreSectionMedias")
      .withIndex("by_section_order")
      .filter((q) => q.eq(q.field("sectionId"), sectionId))
      .order("asc")
      .collect();
  },
});

// Get detailed section media with media info
export const getSelectedBySectionId = query({
  args: { sectionId: v.id("coreSections") },
  handler: async (ctx, { sectionId }) => {
    await requireAuth(ctx, "coreSectionMedias:getSelectedBySectionId");

    const sectionMedias = await ctx.db
      .query("coreSectionMedias")
      .withIndex("by_section_order")
      .filter((q) => q.eq(q.field("sectionId"), sectionId))
      .order("asc")
      .collect();

    // Get media details for each section media
    const detailedSectionMedias = await Promise.all(
      sectionMedias.map(async (sectionMediass) => {
        const media = await ctx.db.get(sectionMediass.mediasId);
        return {
          ...sectionMediass,
          media,
        };
      })
    );

    return detailedSectionMedias;
  },
});

// Add media to section
export const addMedia = mutation({
  args: {
    sectionId: v.id("coreSections"),
    mediasId: v.id("medias"),
    isRequired: v.optional(v.boolean()),
  },
  handler: async (ctx, { sectionId, mediasId, isRequired = false }) => {
    await requireAdminClerk(ctx, "coreSectionMedias:addMedia");

    // Verify section exists and playlist is in draft
    const section = await ctx.db.get(sectionId);
    if (!section) {
      throw new Error("Section not found");
    }

    const playlist = await ctx.db.get(section.corePlaylistId);
    if (playlist?.status === "published") {
      throw new Error("Cannot add media to sections in published playlists");
    }

    // Verify media exists
    const media = await ctx.db.get(mediasId);
    if (!media) {
      throw new Error("Media not found");
    }

    // Check if media already exists in section
    const existingMedia = await ctx.db
      .query("coreSectionMedias")
      .withIndex("by_section")
      .filter((q) => q.and(
        q.eq(q.field("sectionId"), sectionId),
        q.eq(q.field("mediasId"), mediasId)
      ))
      .first();

    if (existingMedia) {
      throw new Error("Media already exists in this section");
    }

    // Get current max order for this section
    const existingSectionMedias = await ctx.db
      .query("coreSectionMedias")
      .withIndex("by_section")
      .filter((q) => q.eq(q.field("sectionId"), sectionId))
      .collect();

    const maxOrder = Math.max(...existingSectionMedias.map(sm => sm.order), 0);

    const sectionMediaId = await ctx.db.insert("coreSectionMedias", {
      sectionId,
      mediasId,
      mediasTitle: media.title || "", // Add required mediasTitle field
      order: maxOrder + 1,
      isRequired,
      createdAt: Date.now(),
    } as any); // Type assertion to bypass TypeScript check

    return sectionMediaId;
  },
});

// Update media selection
export const updateSelection = mutation({
  args: {
    id: v.id("coreSectionMedias"),
    isRequired: v.optional(v.boolean()),
  },
  handler: async (ctx, { id, isRequired }) => {
    await requireAdminClerk(ctx, "coreSectionMedias:updateSelection");

    const sectionMediass = await ctx.db.get(id);
    if (!sectionMediass) {
      throw new Error("Section media not found");
    }

    // Verify section and playlist status
    const section = await ctx.db.get(sectionMediass.sectionId);
    if (!section) {
      throw new Error("Section not found");
    }

    const playlist = await ctx.db.get(section.corePlaylistId);
    if (playlist?.status === "published") {
      throw new Error("Cannot update media in published playlists");
    }

    await ctx.db.patch(id, { isRequired });
    return { success: true };
  },
});

// Reorder media within section
export const reorderMedia = mutation({
  args: {
    mediaOrders: v.array(v.object({
      id: v.id("coreSectionMedias"),
      order: v.number(),
    })),
  },
  handler: async (ctx, { mediaOrders }) => {
    await requireAdminClerk(ctx, "coreSectionMedias:reorderMedia");

    if (mediaOrders.length === 0) return { success: true };

    // Verify first section media exists and check playlist status
    const firstSectionMedia = await ctx.db.get(mediaOrders[0].id);
    if (!firstSectionMedia) throw new Error("Section media not found");

    const section = await ctx.db.get(firstSectionMedia.sectionId);
    if (!section) throw new Error("Section not found");

    const playlist = await ctx.db.get(section.corePlaylistId);
    if (playlist?.status === "published") {
      throw new Error("Cannot reorder media in published playlists");
    }

    for (const { id, order } of mediaOrders) {
      await ctx.db.patch(id, { order });
    }

    return { success: true };
  },
});

// Remove media from section
export const removeMedia = mutation({
  args: { id: v.id("coreSectionMedias") },
  handler: async (ctx, { id }) => {
    await requireAdminClerk(ctx, "coreSectionMedias:removeMedia");

    const sectionMediass = await ctx.db.get(id);
    if (!sectionMediass) {
      throw new Error("Section media not found");
    }

    // Verify section and playlist status
    const section = await ctx.db.get(sectionMediass.sectionId);
    if (!section) {
      throw new Error("Section not found");
    }

    const playlist = await ctx.db.get(section.corePlaylistId);
    if (playlist?.status === "published") {
      throw new Error("Cannot remove media from published playlists");
    }

    await ctx.db.delete(id);
    return { success: true };
  },
});

// Bulk update selections (useful for batch operations)
export const bulkUpdateSelections = mutation({
  args: {
    updates: v.array(v.object({
      id: v.id("coreSectionMedias"),
      isRequired: v.boolean(),
    })),
  },
  handler: async (ctx, { updates }) => {
    await requireAdminClerk(ctx, "coreSectionMedias:bulkUpdateSelections");

    if (updates.length === 0) return { success: true };

    // Verify all section media exist and playlist is in draft
    for (const update of updates) {
      const sectionMediass = await ctx.db.get(update.id);
      if (!sectionMediass) {
        throw new Error(`Section media ${update.id} not found`);
      }

      const section = await ctx.db.get(sectionMediass.sectionId);
      if (!section) {
        throw new Error("Section not found");
      }

      const playlist = await ctx.db.get(section.corePlaylistId);
      if (playlist?.status === "published") {
        throw new Error("Cannot update media in published playlists");
      }

      await ctx.db.patch(update.id, { isRequired: update.isRequired });
    }

    return { success: true };
  },
});

// Get selection count for a section
export const getSelectionCount = query({
  args: { sectionId: v.id("coreSections") },
  handler: async (ctx, { sectionId }) => {
    await requireAuth(ctx, "coreSectionMedias:getSelectionCount");

    const sectionMedias = await ctx.db
      .query("coreSectionMedias")
      .withIndex("by_section")
      .filter((q) => q.eq(q.field("sectionId"), sectionId))
      .collect();

    const totalCount = sectionMedias.length;
    const requiredCount = sectionMedias.filter(sm => sm.isRequired).length;

    return {
      total: totalCount,
      required: requiredCount,
      optional: totalCount - requiredCount,
    };
  },
});
