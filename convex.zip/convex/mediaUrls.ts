// convex/mediaUrls.ts
import { R2 } from "@convex-dev/r2";
import { v } from "convex/values";
import { components } from "./_generated/api";
import { mutation, query } from "./_generated/server";
import { requireAuth } from "./authClerk";

// Initialize R2 component
export const r2 = new R2(components.r2);

/**
 * Generate a fresh signed URL for a media file
 * This function can be called whenever a media URL is needed
 * The URL will be valid for the specified duration (default: 24 hours)
 */
export const getSignedUrl = query({
  args: {
    mediaId: v.id("medias"),
    expirationSeconds: v.optional(v.number()),
  },
  handler: async (ctx, { mediaId, expirationSeconds = 86400 }) => {
    // Require authentication - any authenticated user can access media
    await requireAuth(ctx, "mediaUrls:getSignedUrl");

    // Get the media record
    const media = await ctx.db.get(mediaId);
    if (!media) {
      throw new Error("Media not found");
    }

    // If this is a YouTube video or external URL, just return the original URL
    if (!media.uploadKey || media.mediaType === "video") {
      return { url: media.mediaUrl, isSignedUrl: false };
    }

    // Generate a fresh signed URL with the specified expiration
    // Use the standard R2 getUrl method with expiration parameter
    const signedUrl = await r2.getUrl(media.uploadKey, {
      expiresIn: expirationSeconds,
    });

    return { 
      url: signedUrl, 
      isSignedUrl: true,
      expiresAt: Date.now() + (expirationSeconds * 1000)
    };
  },
});

/**
 * Get signed URLs for multiple media files at once
 * Useful for playlists or other collections of media
 */
export const getBatchSignedUrls = query({
  args: {
    mediaIds: v.array(v.id("medias")),
    expirationSeconds: v.optional(v.number()),
  },
  handler: async (ctx, { mediaIds, expirationSeconds = 86400 }) => {
    // Require authentication
    await requireAuth(ctx, "mediaUrls:getBatchSignedUrls");

    const results = [];

    for (const mediaId of mediaIds) {
      // Get the media record
      const media = await ctx.db.get(mediaId);
      if (!media) {
        results.push({ 
          mediaId: mediaId.toString(), 
          url: null, 
          error: "Media not found",
          isSignedUrl: false
        });
        continue;
      }

      // If this is a YouTube video or external URL, just return the original URL
      if (!media.uploadKey || media.mediaType === "video") {
        results.push({ 
          mediaId: mediaId.toString(), 
          url: media.mediaUrl, 
          isSignedUrl: false,
          title: media.title,
          mediaType: media.mediaType
        });
        continue;
      }

      try {
        // Generate a fresh signed URL with the specified expiration
        const signedUrl = await r2.getUrl(media.uploadKey, {
          expiresIn: expirationSeconds,
        });

        results.push({ 
          mediaId: mediaId.toString(), 
          url: signedUrl, 
          isSignedUrl: true,
          expiresAt: Date.now() + (expirationSeconds * 1000),
          title: media.title,
          mediaType: media.mediaType
        });
      } catch (error) {
        results.push({ 
          mediaId: mediaId.toString(), 
          url: null, 
          error: "Failed to generate signed URL",
          isSignedUrl: false
        });
      }
    }

    return results;
  },
});
