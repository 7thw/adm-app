// convex/auth.ts
import { ConvexError } from "convex/values";
import { MutationCtx, QueryCtx } from "./_generated/server";

// Environment detection
const isDevelopment = process.env.NODE_ENV !== "production";

/**
 * Helper function to check if a user is authenticated
 * In development, it will allow unauthenticated access with a warning
 */
export async function requireAuth(
  ctx: QueryCtx | MutationCtx,
  functionName: string
) {
  const identity = await ctx.auth.getUserIdentity();
  
  if (!identity) {
    if (isDevelopment) {
      console.log(`⚠️ WARNING: Unauthenticated access to ${functionName} (allowed in development)`);
      return null;
    } else {
      throw new ConvexError("Not authenticated");
    }
  }
  
  return identity;
}

/**
 * Helper function to check if a user is an admin
 * In development, it will allow non-admin access with a warning
 */
export async function requireAdmin(
  ctx: QueryCtx | MutationCtx,
  functionName: string
) {
  const identity = await requireAuth(ctx, functionName);
  
  // If we're in development and skipping auth checks
  if (!identity && isDevelopment) {
    return { isAdmin: true, identity: null };
  }
  
  // Check admin permissions using the users table
  const user = identity ? await ctx.db
    .query("users")
    .withIndex("by_token_identifier", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .first() : null;
  
  const isAdmin = !!user && user.role === "admin";
  
  // Get admin profile if the user is an admin
  const adminProfile = isAdmin && user ? await ctx.db
    .query("adminProfiles")
    .withIndex("by_user_id", (q) => q.eq("userId", user._id))
    .first() : null;
  
  if (!isAdmin) {
    if (isDevelopment) {
      console.log(`⚠️ WARNING: Non-admin user accessing ${functionName} (allowed in development)`);
    } else {
      throw new ConvexError("Admin access required");
    }
  }
  
  return { isAdmin: true, identity, user, adminProfile };
}
