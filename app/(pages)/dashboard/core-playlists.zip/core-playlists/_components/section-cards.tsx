"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { List, Eye, Edit, Calendar } from "lucide-react"

export function SectionCards({ data }: { data: any[] }) {
  // Calculate statistics from the data
  const totalPlaylists = data.length;
  const publishedPlaylists = data.filter(item => item.status === "published").length;
  const draftPlaylists = data.filter(item => item.status === "draft").length;
  const totalPlayCount = data.reduce((sum, item) => sum + (item.playCount || 0), 0);

  // Calculate percentages
  const publishedPercentage = totalPlaylists > 0 ? Math.round((publishedPlaylists / totalPlaylists) * 100) : 0;
  const draftPercentage = totalPlaylists > 0 ? Math.round((draftPlaylists / totalPlaylists) * 100) : 0;

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Playlists</CardTitle>
          <List className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{totalPlaylists}</div>
          <p className="text-xs text-muted-foreground">
            All core playlists in system
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Published</CardTitle>
          <Eye className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-green-600">{publishedPlaylists}</div>
          <p className="text-xs text-muted-foreground">
            {publishedPercentage}% of total playlists
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Draft</CardTitle>
          <Edit className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-orange-600">{draftPlaylists}</div>
          <p className="text-xs text-muted-foreground">
            {draftPercentage}% of total playlists
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Plays</CardTitle>
          <Calendar className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-blue-600">{totalPlayCount.toLocaleString()}</div>
          <p className="text-xs text-muted-foreground">
            Across all playlists
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
