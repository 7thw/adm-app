"use client";

import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { useMutation, useQuery } from "convex/react";
import {
  ArrowLeft,
  CheckCircle,
  Circle,
  Clock,
  Edit,
  FileText,
  GripVertical,
  Music,
  Play,
  Plus,
  Save,
  Trash2,
  Video
} from "lucide-react";
import { useParams, useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";

import {
  closestCenter,
  DndContext,
  DragEndEvent,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import {
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Textarea } from "@/components/ui/textarea";

// Types
interface CoreSection {
  _id: Id<"coreSections">;
  title: string;
  description?: string;
  sectionType: "base" | "loop";
  minSelectMedia: number;
  maxSelectMedia: number;
  order: number;
}

interface MediaItem {
  _id: Id<"media">;
  title: string;
  description?: string;
  mediaType: "audio" | "video";
  mediaUrl: string;
  duration?: number;
  fileSize?: number;
  createdAt: number;
}

interface SectionMediaItem {
  _id: Id<"sectionMedia">;
  sectionId: Id<"coreSections">;
  mediaId: Id<"media">;
  media?: MediaItem;
  isRequired: boolean;
  order: number;
}

// Sortable Section Component
function SortableSection({
  section,
  children,
  onEdit,
  onDelete,
  isPublished,
}: {
  section: CoreSection;
  children: React.ReactNode;
  onEdit: (section: CoreSection) => void;
  onDelete: (sectionId: Id<"coreSections">) => void;
  isPublished: boolean;
}) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({
    id: section._id.toString(),
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div ref={setNodeRef} style={style} className="mb-6">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3">
            <div
              {...attributes}
              {...listeners}
              className="cursor-grab p-1 hover:bg-muted rounded"
            >
              <GripVertical className="h-5 w-5 text-muted-foreground" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <CardTitle className="text-lg">{section.title}</CardTitle>
                  <Badge
                    variant={section.sectionType === "base" ? "secondary" : "default"}
                  >
                    {section.sectionType === "base" ? "Base" : "Loop"}
                  </Badge>
                </div>
                <div className="flex items-center gap-2">
                  {!isPublished && (
                    <>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onEdit(section)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onDelete(section._id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
              <CardDescription className="mt-1">
                Select {section.minSelectMedia}-{section.maxSelectMedia} media
                {section.description && ` • ${section.description}`}
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>{children}</CardContent>
      </Card>
    </div>
  );
}

// Inline Media Manager Component
function InlineMediaManager({
  sectionId,
  isPublished,
}: {
  sectionId: Id<"coreSections">;
  isPublished: boolean;
}) {
  const [showAvailableMedia, setShowAvailableMedia] = useState(false);
  const [selectedMediaIds, setSelectedMediaIds] = useState<Set<string>>(new Set());

  // Fetch data
  const sectionMedia = useQuery(api.coreSectionMedia.getBySectionId, { sectionId });
  const allMedia = useQuery(api.media.getAllMedia, { limit: 100 });

  // Mutations
  const addMediaToSection = useMutation(api.coreSectionMedia.addMedia);
  const removeMediaFromSection = useMutation(api.coreSectionMedia.removeMedia);
  const updateMediaSelection = useMutation(api.coreSectionMedia.updateSelection);
  const reorderMedia = useMutation(api.coreSectionMedia.reorderMedia);

  const formatDuration = (seconds?: number) => {
    if (!seconds) return "Unknown";
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`;
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return "Unknown";
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  const handleAddSelectedMedia = async () => {
    try {
      const promises = Array.from(selectedMediaIds).map((mediaId) =>
        addMediaToSection({
          sectionId,
          mediaId: mediaId as Id<"media">,
          isRequired: false,
        })
      );
      await Promise.all(promises);
      toast.success(`Added ${selectedMediaIds.size} media items`);
      setSelectedMediaIds(new Set());
      setShowAvailableMedia(false);
    } catch (error) {
      toast.error("Failed to add media");
    }
  };

  const handleRemoveMedia = async (sectionMediaId: Id<"sectionMedia">) => {
    try {
      await removeMediaFromSection({ id: sectionMediaId });
      toast.success("Media removed from section");
    } catch (error) {
      toast.error("Failed to remove media");
    }
  };

  const handleToggleRequired = async (
    sectionMediaId: Id<"sectionMedia">,
    currentlyRequired: boolean
  ) => {
    try {
      await updateMediaSelection({
        id: sectionMediaId,
        isRequired: !currentlyRequired,
      });
      toast.success(
        `Media ${!currentlyRequired ? "marked as required" : "marked as optional"}`
      );
    } catch (error) {
      toast.error("Failed to update media selection");
    }
  };

  // Get available media (not already in this section)
  const availableMedia =
    allMedia?.filter(
      (media) => !sectionMedia?.some((sm) => sm.mediaId === media._id)
    ) || [];

  return (
    <div className="space-y-4">
      {/* Section Media List */}
      <div className="space-y-3">
        {!sectionMedia || sectionMedia.length === 0 ? (
          <div className="text-center py-8 border-2 border-dashed rounded-lg">
            <Music className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
            <p className="text-muted-foreground">No media added yet</p>
            {!isPublished && (
              <Button
                className="mt-3"
                size="sm"
                onClick={() => setShowAvailableMedia(true)}
              >
                <Plus className="mr-2 h-4 w-4" />
                Add Med
              </Button>
            )}
          </div>
        ) : (
          sectionMedia.map((sectionMediaItem, index) => {
            // Find the corresponding media item from allMedia using mediaId
            const mediaItem = allMedia?.find(m => m._id === sectionMediaItem.mediaId);
            if (!mediaItem) return null;

            return (
              <Card
                key={sectionMediaItem._id}
                className="hover:shadow-sm transition-shadow"
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    {/* Order & Drag Handle */}
                    <div className="flex items-center gap-2">
                      <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />
                      <span className="text-sm font-medium text-muted-foreground">
                        #{index + 1}
                      </span>
                    </div>

                    {/* Media Icon */}
                    <div className="flex-shrink-0">
                      {mediaItem.mediaType === "audio" ? (
                        <Music className="h-6 w-6 text-blue-500" />
                      ) : (
                        <Video className="h-6 w-6 text-red-500" />
                      )}
                    </div>

                    {/* Media Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="font-medium truncate">{mediaItem.title}</h4>
                        <Badge variant="outline" className="text-xs">
                          {mediaItem.mediaType}
                        </Badge>
                        {sectionMediaItem.isRequired && (
                          <Badge variant="default" className="text-xs">
                            Required
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {formatDuration(mediaItem.duration)}
                        </span>
                        {mediaItem.fileSize && (
                          <span className="flex items-center gap-1">
                            <FileText className="h-3 w-3" />
                            {formatFileSize(mediaItem.fileSize)}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Controls */}
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="sm">
                        <Play className="h-4 w-4" />
                      </Button>
                      {!isPublished && (
                        <>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() =>
                              handleToggleRequired(
                                sectionMediaItem._id,
                                !!sectionMediaItem.isRequired
                              )
                            }
                          >
                            {sectionMediaItem.isRequired ? (
                              <CheckCircle className="h-4 w-4 text-green-600" />
                            ) : (
                              <Circle className="h-4 w-4" />
                            )}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRemoveMedia(sectionMediaItem._id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {/* Add Media Section */}
      {!isPublished && (
        <Collapsible
          open={showAvailableMedia}
          onOpenChange={setShowAvailableMedia}
        >
          <div className="flex items-center justify-between">
            <CollapsibleTrigger asChild>
              <Button variant="outline" size="sm" className="gap-2">
                <Plus className="h-4 w-4" />
                Add Media to Section
              </Button>
            </CollapsibleTrigger>
            {sectionMedia && sectionMedia.length > 0 && (
              <div className="text-sm text-muted-foreground">
                {sectionMedia.length} media items
              </div>
            )}
          </div>

          <CollapsibleContent className="mt-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Available Media</CardTitle>
                <CardDescription>
                  Select media to add to this section
                </CardDescription>
              </CardHeader>
              <CardContent>
                {availableMedia.length === 0 ? (
                  <div className="text-center py-6">
                    <Music className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
                    <p className="text-muted-foreground">
                      No available media to add
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {availableMedia.map((media) => (
                      <Card
                        key={media._id}
                        className={`cursor-pointer transition-all ${selectedMediaIds.has(media._id)
                          ? "ring-2 ring-primary bg-primary/5"
                          : "hover:shadow-sm"
                          }`}
                        onClick={() => {
                          const newSelected = new Set(selectedMediaIds);
                          if (newSelected.has(media._id)) {
                            newSelected.delete(media._id);
                          } else {
                            newSelected.add(media._id);
                          }
                          setSelectedMediaIds(newSelected);
                        }}
                      >
                        <CardContent className="p-3">
                          <div className="flex items-center gap-3">
                            <div className="flex-shrink-0">
                              {selectedMediaIds.has(media._id) ? (
                                <CheckCircle className="h-4 w-4 text-primary" />
                              ) : (
                                <Circle className="h-4 w-4 text-muted-foreground" />
                              )}
                            </div>
                            <div className="flex-shrink-0">
                              {media.mediaType === "audio" ? (
                                <Music className="h-5 w-5 text-blue-500" />
                              ) : (
                                <Video className="h-5 w-5 text-red-500" />
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <h4 className="font-medium truncate text-sm">
                                  {media.title}
                                </h4>
                                <Badge variant="outline" className="text-xs">
                                  {media.mediaType}
                                </Badge>
                              </div>
                              <div className="text-xs text-muted-foreground mt-1">
                                {formatDuration(media.duration)}
                                {media.description && ` • ${media.description}`}
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}

                {selectedMediaIds.size > 0 && (
                  <div className="flex justify-end gap-2 mt-4 pt-4 border-t">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedMediaIds(new Set())}
                    >
                      Clear
                    </Button>
                    <Button size="sm" onClick={handleAddSelectedMedia}>
                      Add {selectedMediaIds.size} Media
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </CollapsibleContent>
        </Collapsible>
      )}
    </div>
  );
}

// Main Component
export default function UnifiedCorePlaylistBuilder() {
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;

  // State for playlist editing
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [categoryId, setCategoryId] = useState<Id<"playlistCategories"> | "">("");
  const [status, setStatus] = useState<"draft" | "published">("draft");
  const [isSaving, setIsSaving] = useState(false);

  // State for section management
  const [sections, setSections] = useState<CoreSection[]>([]);
  const [editingSection, setEditingSection] = useState<CoreSection | null>(null);
  const [isAddingSectionOpen, setIsAddingSectionOpen] = useState(false);

  // Sensors for drag and drop
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // Fetch data
  const playlist = useQuery(api.corePlaylists.getByStringId, { id }) as {
    _id: Id<"corePlaylists">;
    title: string;
    description?: string;
    thumbnailUrl?: string;
    status: "draft" | "published";
    categoryId: Id<"playlistCategories">;
    playCount: number;
    totalDuration?: number;
    createdAt: number;
    updatedAt: number;
  } | null | undefined;
  const categories = useQuery(api.playlistCategories.getAll) || [];
  const fetchedSections =
    useQuery(
      api.coreSections.getByCorePlaylistId,
      playlist?._id ? { playlistId: playlist._id } : "skip"
    ) || [];

  // Mutations
  const updatePlaylist = useMutation(api.corePlaylists.update);
  const createSection = useMutation(api.coreSections.create);
  const updateSection = useMutation(api.coreSections.update);
  const deleteSection = useMutation(api.coreSections.remove);
  const reorderSections = useMutation(api.coreSections.reorder);

  const isPublished = status === "published";

  // Initialize form data
  useEffect(() => {
    if (playlist) {
      setTitle(playlist.title);
      setDescription(playlist.description || "");
      setCategoryId(playlist.categoryId);
      setStatus(playlist.status);
    }
  }, [playlist]);

  // Initialize sections
  useEffect(() => {
    if (fetchedSections.length > 0) {
      const sortedSections = [...fetchedSections].sort((a, b) => a.order - b.order);
      setSections(sortedSections);
    }
  }, [fetchedSections]);

  const handleSectionDragEnd = useCallback((event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      setSections((sections) => {
        const oldIndex = sections.findIndex((s) => s._id.toString() === active.id);
        const newIndex = sections.findIndex((s) => s._id.toString() === over.id);

        const reordered = [...sections];
        const [removed] = reordered.splice(oldIndex, 1);
        reordered.splice(newIndex, 0, removed);

        const withNewOrder = reordered.map((section, index) => ({
          ...section,
          order: index + 1,
        }));

        const sectionOrders = withNewOrder.map((s) => ({ id: s._id, order: s.order }));
        reorderSections({ sectionOrders });

        return withNewOrder;
      });
    }
  }, [reorderSections]);

  const handleSavePlaylist = async () => {
    if (!playlist || !title || !categoryId) {
      toast.error("Title and category are required");
      return;
    }

    setIsSaving(true);
    try {
      await updatePlaylist({
        id: playlist._id,
        title,
        description,
        categoryId: categoryId as Id<"playlistCategories">,
        status,
      });
      toast.success("Playlist updated successfully");
    } catch (error) {
      toast.error("Failed to update playlist");
    } finally {
      setIsSaving(false);
    }
  };

  const handleAddSection = async (sectionData: {
    title: string;
    sectionType: "base" | "loop";
    minSelectMedia: number;
    maxSelectMedia: number;
  }) => {
    if (!playlist) return;

    try {
      const highestOrder = sections.length > 0 ? Math.max(...sections.map((s) => s.order)) : 0;

      const newSectionId = await createSection({
        playlistId: playlist._id,
        title: sectionData.title,
        description: "",
        sectionType: sectionData.sectionType,
        minSelectMedia: sectionData.minSelectMedia,
        maxSelectMedia: sectionData.maxSelectMedia,
        // Note: order is handled internally by the Convex function
      });

      const newSection: CoreSection = {
        _id: newSectionId,
        title: sectionData.title,
        description: "",
        sectionType: sectionData.sectionType,
        minSelectMedia: sectionData.minSelectMedia,
        maxSelectMedia: sectionData.maxSelectMedia,
        order: highestOrder + 1,
      };

      setSections((prev) => [...prev, newSection]);
      setIsAddingSectionOpen(false);
      toast.success("Section added successfully");
    } catch (error) {
      toast.error("Failed to add section");
    }
  };

  const handleEditSection = async (sectionData: CoreSection) => {
    try {
      await updateSection({
        id: sectionData._id,
        title: sectionData.title,
        description: sectionData.description,
        sectionType: sectionData.sectionType,
        minSelectMedia: sectionData.minSelectMedia,
        maxSelectMedia: sectionData.maxSelectMedia,
      });

      setSections((prev) => prev.map((s) => (s._id === sectionData._id ? sectionData : s)));
      setEditingSection(null);
      toast.success("Section updated successfully");
    } catch (error) {
      toast.error("Failed to update section");
    }
  };

  const handleDeleteSection = async (sectionId: Id<"coreSections">) => {
    try {
      await deleteSection({ id: sectionId });
      setSections((prev) => prev.filter((s) => s._id !== sectionId));
      toast.success("Section deleted successfully");
    } catch (error) {
      toast.error("Failed to delete section");
    }
  };

  if (!playlist) {
    return <div className="p-6">Loading...</div>;
  }

  return (
    <div className="space-y-6 p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            size="icon"
            onClick={() => router.push("/dashboard/core-playlists")}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-2xl font-bold">Core Playlist Builder</h1>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant={isPublished ? "default" : "secondary"}>
            {isPublished ? "Published" : "Draft"}
          </Badge>
          <Button onClick={handleSavePlaylist} disabled={isSaving}>
            <Save className="mr-2 h-4 w-4" />
            {isSaving ? "Saving..." : "Save Playlist"}
          </Button>
        </div>
      </div>

      {/* Playlist Details */}
      <Card>
        <CardHeader>
          <CardTitle>Playlist Details</CardTitle>
          <CardDescription>Configure the basic information for this playlist</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter playlist title"
                disabled={isPublished}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select
                value={categoryId ? categoryId.toString() : ""}
                onValueChange={(value) => setCategoryId(value as Id<"playlistCategories">)}
                disabled={isPublished}
              >
                <SelectTrigger id="category">
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category._id} value={category._id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Enter playlist description"
              rows={3}
              disabled={isPublished}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="status">Status</Label>
            <Select
              value={status}
              onValueChange={(value) => setStatus(value as "draft" | "published")}
            >
              <SelectTrigger id="status" className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="published">Published</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Sections */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold">Playlist Sections</h2>
            <p className="text-muted-foreground">
              Organize your playlist into sections with customizable media selection
            </p>
          </div>
          {!isPublished && (
            <Sheet open={isAddingSectionOpen} onOpenChange={setIsAddingSectionOpen}>
              <SheetTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Section
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>Add New Section</SheetTitle>
                  <SheetDescription>
                    Create a new section for organizing media in your playlist
                  </SheetDescription>
                </SheetHeader>
                <AddSectionForm onAdd={handleAddSection} />
              </SheetContent>
            </Sheet>
          )}
        </div>

        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleSectionDragEnd}
        >
          <SortableContext
            items={sections.map((s) => s._id.toString())}
            strategy={verticalListSortingStrategy}
          >
            {sections.map((section) => (
              <SortableSection
                key={section._id}
                section={section}
                onEdit={setEditingSection}
                onDelete={handleDeleteSection}
                isPublished={isPublished}
              >
                <InlineMediaManager sectionId={section._id} isPublished={isPublished} />
              </SortableSection>
            ))}
          </SortableContext>
        </DndContext>

        {sections.length === 0 && (
          <div className="text-center py-12 border-2 border-dashed rounded-lg">
            <Music className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No sections yet</h3>
            <p className="text-muted-foreground mb-4">
              Add your first section to start building your playlist
            </p>
            {!isPublished && (
              <Button onClick={() => setIsAddingSectionOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Add Your First Section
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Edit Section Sheet */}
      {editingSection && (
        <Sheet
          open={!!editingSection}
          onOpenChange={(open) => !open && setEditingSection(null)}
        >
          <SheetContent>
            <SheetHeader>
              <SheetTitle>Edit Section</SheetTitle>
              <SheetDescription>Update the section configuration</SheetDescription>
            </SheetHeader>
            <EditSectionForm
              section={editingSection}
              onSave={handleEditSection}
              onCancel={() => setEditingSection(null)}
            />
          </SheetContent>
        </Sheet>
      )}
    </div>
  );
}

// Add Section Form Component
function AddSectionForm({ onAdd }: { onAdd: (data: any) => void }) {
  const [title, setTitle] = useState("");
  const [sectionType, setSectionType] = useState<"base" | "loop">("base");
  const [minSelectMedia, setMinSelectMedia] = useState(1);
  const [maxSelectMedia, setMaxSelectMedia] = useState(3);

  const handleSubmit = () => {
    if (!title.trim()) {
      toast.error("Section title is required");
      return;
    }

    onAdd({
      title,
      sectionType,
      minSelectMedia,
      maxSelectMedia,
    });

    // Reset form
    setTitle("");
    setSectionType("base");
    setMinSelectMedia(1);
    setMaxSelectMedia(3);
  };

  return (
    <div className="py-4 space-y-4">
      <div className="space-y-2">
        <Label htmlFor="section-title">Title</Label>
        <Input
          id="section-title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Enter section title"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="section-type">Type</Label>
        <Select value={sectionType} onValueChange={(value) => setSectionType(value as "base" | "loop")}>
          <SelectTrigger id="section-type">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="base">Base (plays once)</SelectItem>
            <SelectItem value="loop">Loop (repeats)</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="min-select">Min Select</Label>
          <Input
            id="min-select"
            type="number"
            min="0"
            value={minSelectMedia}
            onChange={(e) => setMinSelectMedia(parseInt(e.target.value) || 0)}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="max-select">Max Select</Label>
          <Input
            id="max-select"
            type="number"
            min="1"
            value={maxSelectMedia}
            onChange={(e) => setMaxSelectMedia(parseInt(e.target.value) || 1)}
          />
        </div>
      </div>
      <Button className="w-full mt-6" onClick={handleSubmit}>
        Add Section
      </Button>
    </div>
  );
}

// Edit Section Form Component
function EditSectionForm({
  section,
  onSave,
  onCancel,
}: {
  section: CoreSection;
  onSave: (section: CoreSection) => void;
  onCancel: () => void;
}) {
  const [title, setTitle] = useState(section.title);
  const [description, setDescription] = useState(section.description || "");
  const [sectionType, setSectionType] = useState(section.sectionType);
  const [minSelectMedia, setMinSelectMedia] = useState(section.minSelectMedia);
  const [maxSelectMedia, setMaxSelectMedia] = useState(section.maxSelectMedia);

  const handleSave = () => {
    if (!title.trim()) {
      toast.error("Section title is required");
      return;
    }

    onSave({
      ...section,
      title,
      description,
      sectionType,
      minSelectMedia,
      maxSelectMedia,
    });
  };

  return (
    <div className="py-4 space-y-4">
      <div className="space-y-2">
        <Label htmlFor="edit-title">Title</Label>
        <Input
          id="edit-title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Enter section title"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="edit-description">Description</Label>
        <Textarea
          id="edit-description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Enter section description"
          rows={3}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="edit-type">Type</Label>
        <Select value={sectionType} onValueChange={(value) => setSectionType(value as "base" | "loop")}>
          <SelectTrigger id="edit-type">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="base">Base (plays once)</SelectItem>
            <SelectItem value="loop">Loop (repeats)</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="edit-min-select">Min Select</Label>
          <Input
            id="edit-min-select"
            type="number"
            min="0"
            value={minSelectMedia}
            onChange={(e) => setMinSelectMedia(parseInt(e.target.value) || 0)}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="edit-max-select">Max Select</Label>
          <Input
            id="edit-max-select"
            type="number"
            min="1"
            value={maxSelectMedia}
            onChange={(e) => setMaxSelectMedia(parseInt(e.target.value) || 1)}
          />
        </div>
      </div>
      <div className="flex gap-3 mt-6">
        <Button variant="outline" onClick={onCancel} className="flex-1">
          Cancel
        </Button>
        <Button onClick={handleSave} className="flex-1">
          Save Changes
        </Button>
      </div>
    </div>
  );
}
