"use client"

import {
  closestCenter,
  DndContext,
  KeyboardSensor,
  MouseSensor,
  TouchSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
  type UniqueIdentifier,
} from "@dnd-kit/core"
import { restrictToVerticalAxis } from "@dnd-kit/modifiers"
import {
  arrayMove,
  SortableContext,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"
import {
  Music,
  Video,
  Clock,
  FileText,
  Play,
  GripVertical,
  MoreHorizontal,
  CheckCircle,
  Circle,
  Trash2,
  Plus,
  ChevronDown,
} from "lucide-react"
import {
  ColumnDef,
  ColumnFiltersState,
  flexRender,
  getCoreRowModel,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  Row,
  SortingState,
  useReactTable,
  VisibilityState,
} from "@tanstack/react-table"
import * as React from "react"
import { toast } from "sonner"
import { z } from "zod"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

// Media schema for the data table
export const mediaSchema = z.object({
  _id: z.string(),
  title: z.string(),
  description: z.string().optional(),
  mediaType: z.enum(["audio", "video"]),
  mediaUrl: z.string(),
  duration: z.number().optional(),
  fileSize: z.number().optional(),
  isRequired: z.boolean(),
  order: z.number(),
})

export type MediaItem = z.infer<typeof mediaSchema>

// Create a separate component for the drag handle
function DragHandle({ id }: { id: string }) {
  const { attributes, listeners } = useSortable({
    id,
  })

  return (
    <Button
      {...attributes}
      {...listeners}
      variant="ghost"
      size="icon"
      className="text-muted-foreground size-7 hover:bg-transparent cursor-grab"
    >
      <GripVertical className="text-muted-foreground size-4" />
      <span className="sr-only">Drag to reorder</span>
    </Button>
  )
}

interface MediaDataTableProps {
  data: MediaItem[]
  onReorder: (reorderedData: MediaItem[]) => void
  onToggleRequired: (mediaId: string, isRequired: boolean) => void
  onRemoveMedia: (mediaId: string) => void
  onPlayMedia: (media: MediaItem) => void
  isPublished?: boolean
}

export function MediaDataTable({
  data: initialData,
  onReorder,
  onToggleRequired,
  onRemoveMedia,
  onPlayMedia,
  isPublished = false
}: MediaDataTableProps) {
  const [data, setData] = React.useState(() => initialData)
  const [rowSelection, setRowSelection] = React.useState({})
  const [columnVisibility, setColumnVisibility] = React.useState<VisibilityState>({})
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])
  const [sorting, setSorting] = React.useState<SortingState>([])
  
  // Update local data when props change
  React.useEffect(() => {
    setData(initialData)
  }, [initialData])

  const formatDuration = (seconds?: number) => {
    if (!seconds) return "Unknown"
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return "Unknown"
    const mb = bytes / (1024 * 1024)
    return `${mb.toFixed(1)} MB`
  }

  const columns: ColumnDef<MediaItem>[] = [
    {
      id: "drag",
      header: () => null,
      cell: ({ row }) => !isPublished && <DragHandle id={row.original._id} />,
      size: 40,
    },
    {
      id: "select",
      header: ({ table }) => !isPublished && (
        <div className="flex items-center justify-center">
          <Checkbox
            checked={
              table.getIsAllPageRowsSelected() ||
              (table.getIsSomePageRowsSelected() && "indeterminate")
            }
            onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
            aria-label="Select all"
          />
        </div>
      ),
      cell: ({ row }) => !isPublished && (
        <div className="flex items-center justify-center">
          <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Select row"
          />
        </div>
      ),
      enableSorting: false,
      enableHiding: false,
      size: 40,
    },
    {
      id: "mediaInfo",
      header: "Media",
      cell: ({ row }) => {
        const media = row.original
        return (
          <div className="flex items-center gap-3">
            <div className="flex-shrink-0">
              {media.mediaType === "audio" ? (
                <Music className="h-6 w-6 text-blue-500" />
              ) : (
                <Video className="h-6 w-6 text-red-500" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h4 className="font-medium truncate">{media.title}</h4>
                <Badge variant="outline" className="text-xs">
                  {media.mediaType}
                </Badge>
                {media.isRequired && (
                  <Badge variant="default" className="text-xs">
                    Required
                  </Badge>
                )}
              </div>
              {media.description && (
                <p className="text-sm text-muted-foreground truncate mt-1">
                  {media.description}
                </p>
              )}
            </div>
          </div>
        )
      },
      enableHiding: false,
    },
    {
      accessorKey: "duration",
      header: "Duration",
      cell: ({ row }) => (
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <Clock className="h-3 w-3" />
          {formatDuration(row.original.duration)}
        </div>
      ),
      size: 100,
    },
    {
      accessorKey: "fileSize",
      header: "Size",
      cell: ({ row }) => (
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <FileText className="h-3 w-3" />
          {formatFileSize(row.original.fileSize)}
        </div>
      ),
      size: 100,
    },
    {
      id: "required",
      header: "Required",
      cell: ({ row }) => {
        const media = row.original
        return !isPublished ? (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onToggleRequired(media._id, !media.isRequired)}
            className="h-8 w-8 p-0"
          >
            {media.isRequired ? (
              <CheckCircle className="h-4 w-4 text-green-600" />
            ) : (
              <Circle className="h-4 w-4" />
            )}
          </Button>
        ) : (
          media.isRequired ? (
            <CheckCircle className="h-4 w-4 text-green-600" />
          ) : (
            <Circle className="h-4 w-4 text-muted-foreground" />
          )
        )
      },
      size: 80,
    },
    {
      id: "actions",
      header: "Actions",
      cell: ({ row }) => {
        const media = row.original
        return (
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onPlayMedia(media)}
              className="h-8 w-8 p-0"
            >
              <Play className="h-4 w-4" />
            </Button>
            {!isPublished && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="h-8 w-8 p-0"
                  >
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem
                    onClick={() => onToggleRequired(media._id, !media.isRequired)}
                  >
                    {media.isRequired ? "Mark Optional" : "Mark Required"}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => onRemoveMedia(media._id)}
                    className="text-destructive"
                  >
                    Remove from Section
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        )
      },
      size: 100,
    },
  ]

  const sortableId = React.useId()
  const sensors = useSensors(
    useSensor(MouseSensor, {}),
    useSensor(TouchSensor, {}),
    useSensor(KeyboardSensor, {})
  )

  const dataIds = React.useMemo<UniqueIdentifier[]>(
    () => data?.map(({ _id }) => _id) || [],
    [data]
  )

  const table = useReactTable({
    data,
    columns,
    state: {
      sorting,
      columnVisibility,
      rowSelection,
      columnFilters,
    },
    getRowId: (row) => row._id,
    enableRowSelection: !isPublished,
    onRowSelectionChange: setRowSelection,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onColumnVisibilityChange: setColumnVisibility,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFacetedRowModel: getFacetedRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
  })

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event
    if (active && over && active.id !== over.id) {
      const newData = (() => {
        const oldIndex = dataIds.indexOf(active.id)
        const newIndex = dataIds.indexOf(over.id)
        return arrayMove(data, oldIndex, newIndex)
      })()
      
      setData(newData)
      onReorder(newData)
    }
  }

  function DraggableRow({ row }: { row: Row<MediaItem> }) {
    const { transform, transition, setNodeRef, isDragging } = useSortable({
      id: row.original._id,
    })

    return (
      <TableRow
        data-state={row.getIsSelected() && "selected"}
        data-dragging={isDragging}
        ref={setNodeRef}
        className="relative z-0 data-[dragging=true]:z-10 data-[dragging=true]:opacity-80"
        style={{
          transform: CSS.Transform.toString(transform),
          transition: transition,
        }}
      >
        {row.getVisibleCells().map((cell) => (
          <TableCell key={cell.id}>
            {flexRender(cell.column.columnDef.cell, cell.getContext())}
          </TableCell>
        ))}
      </TableRow>
    )
  }

  if (!data || data.length === 0) {
    return (
      <div className="text-center py-8 border-2 border-dashed rounded-lg">
        <Music className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
        <p className="text-muted-foreground">No media in this section</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">
            {data.length} media item{data.length !== 1 ? 's' : ''}
          </span>
          {!isPublished && table.getFilteredSelectedRowModel().rows.length > 0 && (
            <span className="text-sm text-muted-foreground">
              ({table.getFilteredSelectedRowModel().rows.length} selected)
            </span>
          )}
        </div>
        {!isPublished && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <ChevronDown className="h-4 w-4" />
                View Options
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              {table
                .getAllColumns()
                .filter(
                  (column) =>
                    typeof column.accessorFn !== "undefined" &&
                    column.getCanHide()
                )
                .map((column) => {
                  return (
                    <DropdownMenuCheckboxItem
                      key={column.id}
                      className="capitalize"
                      checked={column.getIsVisible()}
                      onCheckedChange={(value) =>
                        column.toggleVisibility(!!value)
                      }
                    >
                      {column.id}
                    </DropdownMenuCheckboxItem>
                  )
                })}
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>

      <div className="overflow-hidden rounded-lg border">
        <DndContext
          collisionDetection={closestCenter}
          modifiers={[restrictToVerticalAxis]}
          onDragEnd={handleDragEnd}
          sensors={sensors}
          id={sortableId}
        >
          <Table>
            <TableHeader className="bg-muted/50">
              {table.getHeaderGroups().map((headerGroup) => (
                <TableRow key={headerGroup.id}>
                  {headerGroup.headers.map((header) => {
                    return (
                      <TableHead key={header.id} colSpan={header.colSpan}>
                        {header.isPlaceholder
                          ? null
                          : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                      </TableHead>
                    )
                  })}
                </TableRow>
              ))}
            </TableHeader>
            <TableBody>
              {table.getRowModel().rows?.length ? (
                <SortableContext
                  items={dataIds}
                  strategy={verticalListSortingStrategy}
                >
                  {table.getRowModel().rows.map((row) => (
                    <DraggableRow key={row.id} row={row} />
                  ))}
                </SortableContext>
              ) : (
                <TableRow>
                  <TableCell
                    colSpan={columns.length}
                    className="h-24 text-center"
                  >
                    No media found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </DndContext>
      </div>

      {!isPublished && table.getFilteredSelectedRowModel().rows.length > 0 && (
        <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
          <span className="text-sm font-medium">
            {table.getFilteredSelectedRowModel().rows.length} selected
          </span>
          <div className="flex gap-2 ml-auto">
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                const selectedRows = table.getFilteredSelectedRowModel().rows
                selectedRows.forEach(row => {
                  onToggleRequired(row.original._id, true)
                })
                setRowSelection({})
              }}
            >
              Mark Required
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                const selectedRows = table.getFilteredSelectedRowModel().rows
                selectedRows.forEach(row => {
                  onToggleRequired(row.original._id, false)
                })
                setRowSelection({})
              }}
            >
              Mark Optional
            </Button>
            <Button
              size="sm"
              variant="destructive"
              onClick={() => {
                const selectedRows = table.getFilteredSelectedRowModel().rows
                selectedRows.forEach(row => {
                  onRemoveMedia(row.original._id)
                })
                setRowSelection({})
              }}
            >
              Remove Selected
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}