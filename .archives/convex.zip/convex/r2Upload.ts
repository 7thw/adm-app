import { R2 } from "@convex-dev/r2";
import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

/**
 * R2 client for file uploads
 * This is the server-side implementation for @convex-dev/r2/react's useUploadFile hook
 */
export default new R2({
  bucket: "media-uploads",
  maxSize: 50 * 1024 * 1024,
  validate: async (file: File) => {
    // Allow audio and video files only
    const validAudioTypes = ["audio/mpeg", "audio/mp3", "audio/wav", "audio/ogg"];
    const validVideoTypes = ["video/mp4", "video/webm"];
    const validTypes = [...validAudioTypes, ...validVideoTypes];

    if (!validTypes.includes(file.type)) {
      throw new Error(`Invalid file type: ${file.type}. Only audio and video files are allowed.`);
    }

    return {
      metadata: {
        contentType: file.type,
        originalName: file.name,
        size: file.size,
      },
    };
  },
} as any); // Type assertion to bypass R2 typing issues
/**
 * Get a media document by ID
 */
export const getMediaById = query({
  args: { mediaId: v.id("medias") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.mediaId);
  },
});

/**
 * Generate a streaming URL for media content with authentication and subscription validation
 * This URL is time-limited and intended for streaming media in the browser
 */
export const getMediaStreamUrl = mutation({
  args: {
    mediaId: v.id("medias"),
  },
  handler: async (ctx, { mediaId }) => {
    // Get the media document
    const media = await ctx.db.get(mediaId);
    if (!media) {
      throw new Error("Media not found");
    }

    // Check if user has access to this media
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new Error("Authentication required");
    }

    // Get user profile to check subscription status
    const clerkId = identity.tokenIdentifier.split("|")[1];
    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_clerk_user_id", (q: any) => q.eq("clerkUserId", clerkId))
      .unique();

    if (!userProfile) {
      throw new Error("User profile not found");
    }

    // Check if media is public or user has active subscription
    if (!media.isPublic &&
      (userProfile.role !== "admin" &&
        userProfile.subscriptionStatus !== "active")) {
      throw new Error("Active subscription required to access this media");
    }

    // Check if media has storage ID
    if (!media.storageId) {
      throw new Error("Media has no associated storage");
    }

    // Generate a signed URL with 15 minute expiration (default)
    const url = await ctx.storage.getUrl(media.storageId);

    return { url };
  },
});

/**
 * Generate a download URL for media content with authentication and subscription validation
 * This URL has a longer expiration time and is intended for offline downloads
 */
export const getMediaDownloadUrl = mutation({
  args: {
    mediaId: v.id("medias"),
  },
  handler: async (ctx, { mediaId }) => {
    // Get the media document
    const media = await ctx.db.get(mediaId);
    if (!media) {
      throw new Error("Media not found");
    }

    // Check if user has access to this media
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new Error("Authentication required");
    }

    // Get user profile to check subscription status
    const clerkId = identity.tokenIdentifier.split("|")[1];
    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_clerk_user_id", (q: any) => q.eq("clerkUserId", clerkId))
      .unique();

    if (!userProfile) {
      throw new Error("User profile not found");
    }

    // Check if media is public or user has active subscription
    if (!media.isPublic &&
      (userProfile.role !== "admin" &&
        userProfile.subscriptionStatus !== "active")) {
      throw new Error("Active subscription required to access this media");
    }

    // Check if media has storage ID
    if (!media.storageId) {
      throw new Error("Media has no associated storage");
    }

    // Generate a signed URL with download flag
    // Using type assertion to bypass TypeScript error with getUrl parameters
    const url = await (ctx.storage.getUrl as any)(media.storageId, { download: true });

    return { url, fileName: media.title || "media-download" };
  },
});
